import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enum types
export enum AuditType {
  BASIC = 'basic',
  FULL = 'full'
}

export enum AuditStatus {
  PENDING = 'pending',
  RUNNING = 'running',
  COMPLETED = 'completed',
  FAILED = 'failed'
}

// Users Table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  tokens: integer("tokens").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true,
  createdAt: true,
  updatedAt: true
});

// SEO Audits Table
export const seoAudits = pgTable("seo_audits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  url: text("url").notNull(),
  type: text("type").notNull(), // 'basic' or 'full'
  useAI: boolean("use_ai").notNull().default(false),
  status: text("status").notNull().default('pending'), // 'pending', 'running', 'completed', 'failed'
  score: integer("score"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const insertSeoAuditSchema = createInsertSchema(seoAudits).omit({ 
  id: true,
  createdAt: true,
  completedAt: true,
  score: true,
  status: true
});

// SEO Audit Reports Table
export const seoAuditReports = pgTable("seo_audit_reports", {
  id: serial("id").primaryKey(),
  auditId: integer("audit_id").notNull().references(() => seoAudits.id),
  technicalSeoScore: integer("technical_seo_score").notNull(),
  contentQualityScore: integer("content_quality_score").notNull(),
  performanceScore: integer("performance_score").notNull(),
  mobileFriendlinessScore: integer("mobile_friendliness_score").notNull(),
  backlinksScore: integer("backlinks_score"),
  strengths: json("strengths").notNull().default([]),
  criticalIssues: json("critical_issues").notNull().default([]),
  secondaryIssues: json("secondary_issues").notNull().default([]),
  recommendations: json("recommendations").notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertSeoAuditReportSchema = createInsertSchema(seoAuditReports).omit({ 
  id: true,
  createdAt: true
});

// Token Packages Table
export const tokenPackages = pgTable("token_packages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // stored in cents
  tokens: integer("tokens").notNull(),
  isPopular: boolean("is_popular").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTokenPackageSchema = createInsertSchema(tokenPackages).omit({ 
  id: true,
  createdAt: true
});

// Payments Table
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  packageId: integer("package_id").references(() => tokenPackages.id),
  amount: integer("amount").notNull(), // stored in cents
  paymentIntentId: text("payment_intent_id"),
  status: text("status").notNull().default('pending'), // 'pending', 'succeeded', 'failed'
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertPaymentSchema = createInsertSchema(payments).omit({ 
  id: true,
  createdAt: true,
  updatedAt: true
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSeoAudit = z.infer<typeof insertSeoAuditSchema>;
export type SeoAudit = typeof seoAudits.$inferSelect;

export type InsertSeoAuditReport = z.infer<typeof insertSeoAuditReportSchema>;
export type SeoAuditReport = typeof seoAuditReports.$inferSelect;

export type InsertTokenPackage = z.infer<typeof insertTokenPackageSchema>;
export type TokenPackage = typeof tokenPackages.$inferSelect;

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
