import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { AuditType, User } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from "@/components/ui/alert-dialog";

interface AuditFormValues {
  url: string;
  type: AuditType;
  useAI: boolean;
}

const AuditTool = () => {
  const [previewImage, setPreviewImage] = useState("https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400");
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Check if user is logged in
  const { data: user, isLoading: isLoadingUser } = useQuery<User | null>({
    queryKey: ['/api/user/current'],
    retry: false,
    staleTime: 300000, // 5 minutes
  });
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<AuditFormValues>({
    defaultValues: {
      url: "",
      type: AuditType.BASIC,
      useAI: false
    }
  });
  
  const auditType = watch("type");
  const useAI = watch("useAI");
  
  const { mutate: startAudit, isPending } = useMutation({
    mutationFn: async (data: AuditFormValues) => {
      const response = await apiRequest("POST", "/api/audit", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Audit started",
        description: "Your SEO audit has been started successfully.",
      });
      // Redirect to report page or dashboard
      navigate("/dashboard");
    },
    onError: (error) => {
      if (error.message?.includes("401")) {
        setShowAuthDialog(true);
      } else {
        toast({
          title: "Error",
          description: error.message || "Failed to start audit. Please try again.",
          variant: "destructive",
        });
      }
    },
  });
  
  const onSubmit = (data: AuditFormValues) => {
    // Check if user is logged in first
    if (!user && !isLoadingUser) {
      setShowAuthDialog(true);
      return;
    }
    
    // Validate URL format
    try {
      new URL(data.url);
      startAudit(data);
    } catch (e) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL including http:// or https://",
        variant: "destructive",
      });
    }
  };

  return (
    <div id="audit-tool" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
      {/* Authentication Dialog */}
      <AlertDialog open={showAuthDialog} onOpenChange={setShowAuthDialog}>
        <AlertDialogContent className="bg-cyberpunk-card border border-neon-purple">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-orbitron text-white">Authentication Required</AlertDialogTitle>
            <AlertDialogDescription className="text-gray-300">
              You need to be logged in to perform an SEO audit. Would you like to sign in or create a new account?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex flex-col space-y-2 sm:space-y-0 sm:flex-row sm:space-x-2">
            <AlertDialogCancel className="bg-transparent border border-gray-600 text-gray-300 hover:bg-gray-800">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              className="bg-gradient-to-r from-neon-purple to-neon-blue text-white"
              onClick={() => {
                navigate("/auth");
              }}
            >
              Sign In
            </AlertDialogAction>
            <AlertDialogAction 
              className="bg-gradient-to-r from-neon-green to-neon-blue text-white"
              onClick={() => {
                navigate("/auth?tab=register");
              }}
            >
              Create Account
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      <div className="glass-effect rounded-xl p-8 neon-border">
        <h2 className="text-3xl font-bold font-orbitron mb-6 text-white">Website Audit <span className="text-neon-blue">Tool</span></h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form Section */}
          <div className="lg:col-span-1">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-4">
                <Label htmlFor="website-url" className="block text-sm font-medium text-gray-300 mb-2">Website URL</Label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i className="fas fa-globe text-gray-500"></i>
                  </div>
                  <Input
                    type="url"
                    id="website-url"
                    placeholder="https://example.com"
                    className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple block w-full pl-10 pr-12 py-3 rounded-md shadow-sm text-white"
                    {...register("url", { 
                      required: "URL is required",
                      pattern: {
                        value: /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/,
                        message: "Please enter a valid URL"
                      }
                    })}
                  />
                </div>
                {errors.url && (
                  <p className="mt-1 text-sm text-neon-red">{errors.url.message}</p>
                )}
              </div>
              
              <div className="mb-6">
                <p className="block text-sm font-medium text-gray-300 mb-2">Audit Options</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div 
                    className={`relative bg-cyberpunk-card rounded-md p-4 border ${auditType === AuditType.BASIC ? 'border-neon-purple' : 'border-cyberpunk-card-light hover:border-neon-purple'} transition-colors cursor-pointer group`}
                    onClick={() => setValue("type", AuditType.BASIC)}
                  >
                    <input 
                      type="radio" 
                      id="basic-audit" 
                      value={AuditType.BASIC}
                      checked={auditType === AuditType.BASIC}
                      className="hidden"
                      {...register("type")}
                    />
                    <div className="flex justify-between items-start">
                      <div>
                        <Label htmlFor="basic-audit" className="font-medium text-white cursor-pointer">Basic Audit</Label>
                        <p className="text-sm text-gray-400">Essential SEO checks</p>
                      </div>
                      <span className="text-neon-yellow font-orbitron">100 <i className="fas fa-bolt text-xs"></i></span>
                    </div>
                  </div>
                  <div 
                    className={`relative bg-cyberpunk-card rounded-md p-4 border ${auditType === AuditType.FULL ? 'border-neon-blue' : 'border-cyberpunk-card-light hover:border-neon-blue'} transition-colors cursor-pointer group`}
                    onClick={() => setValue("type", AuditType.FULL)}
                  >
                    <input 
                      type="radio" 
                      id="full-audit" 
                      value={AuditType.FULL}
                      checked={auditType === AuditType.FULL}
                      className="hidden"
                      {...register("type")}
                    />
                    <div className="flex justify-between items-start">
                      <div>
                        <Label htmlFor="full-audit" className="font-medium text-white cursor-pointer">Full Audit</Label>
                        <p className="text-sm text-gray-400">Comprehensive analysis</p>
                      </div>
                      <span className="text-neon-yellow font-orbitron">250 <i className="fas fa-bolt text-xs"></i></span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <div 
                  className={`relative bg-cyberpunk-card rounded-md p-4 border ${useAI ? 'border-neon-green' : 'border-cyberpunk-card-light hover:border-neon-green'} transition-colors cursor-pointer`}
                >
                  <div className="flex">
                    <div className="flex items-center h-5">
                      <Checkbox
                        id="ai-analysis"
                        checked={useAI}
                        onCheckedChange={(checked) => setValue("useAI", checked as boolean)}
                        className="focus:ring-neon-green h-4 w-4 text-neon-green border-cyberpunk-card-light rounded bg-cyberpunk-card"
                      />
                    </div>
                    <div className="ml-3 flex justify-between w-full cursor-pointer" onClick={() => setValue("useAI", !useAI)}>
                      <div>
                        <Label htmlFor="ai-analysis" className="font-medium text-white cursor-pointer">Mistral AI Analysis</Label>
                        <p className="text-sm text-gray-400">Enhanced insights & recommendations</p>
                      </div>
                      <span className="text-neon-yellow font-orbitron">+150 <i className="fas fa-bolt text-xs"></i></span>
                    </div>
                  </div>
                </div>
              </div>
              
              <Button 
                type="submit" 
                disabled={isPending}
                className="w-full bg-gradient-to-r from-neon-purple to-neon-blue text-white py-3 px-4 rounded-md font-medium shadow-lg hover:shadow-xl neon-button transition flex items-center justify-center"
              >
                {isPending ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </>
                ) : (
                  <>
                    <i className="fas fa-search mr-2"></i> Start Audit
                  </>
                )}
              </Button>
            </form>
          </div>
          
          {/* Results Preview Section */}
          <div className="lg:col-span-2">
            <div className="h-full bg-cyberpunk-card rounded-xl p-6 border border-cyberpunk-card-light overflow-hidden relative">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-orbitron text-white">Audit Results Preview</h3>
                <span className="text-gray-400 text-sm">Last audit: <span className="text-neon-blue">Never</span></span>
              </div>
              
              <div className="tech-pattern rounded-lg p-6 text-center">
                <img 
                  src={previewImage} 
                  alt="Futuristic SEO dashboard preview" 
                  className="mx-auto rounded-lg opacity-60 hover:opacity-100 transition-opacity"
                />
                
                <p className="mt-4 text-lg text-white">Enter a URL above to see your SEO audit results</p>
                <p className="text-gray-400">Get detailed insights and actionable recommendations</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuditTool;
