import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-cyberpunk-bg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-neon-blue font-orbitron font-bold mb-4">SEOWISE</h3>
            <ul className="space-y-2">
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">About Us</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Blog</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Careers</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Contact</span></Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-neon-blue font-orbitron font-bold mb-4">Features</h3>
            <ul className="space-y-2">
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Technical SEO</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Content Analysis</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Performance Testing</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">AI Recommendations</span></Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-neon-blue font-orbitron font-bold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Documentation</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">API Access</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">SEO Guide</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Support Center</span></Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-neon-blue font-orbitron font-bold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Terms of Service</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Privacy Policy</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Cookie Policy</span></Link></li>
              <li><Link href="#"><span className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">GDPR Compliance</span></Link></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-cyberpunk-card-light flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <span className="text-neon-purple font-orbitron text-2xl font-bold tracking-wider">SEO<span className="text-neon-blue">WISE</span></span>
            <span className="ml-2 text-gray-400">© {new Date().getFullYear()}. All rights reserved.</span>
          </div>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">
              <i className="fab fa-twitter text-xl"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">
              <i className="fab fa-facebook text-xl"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">
              <i className="fab fa-instagram text-xl"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">
              <i className="fab fa-github text-xl"></i>
            </a>
            <a href="#" className="text-gray-400 hover:text-neon-blue transition-colors">
              <i className="fab fa-linkedin text-xl"></i>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
