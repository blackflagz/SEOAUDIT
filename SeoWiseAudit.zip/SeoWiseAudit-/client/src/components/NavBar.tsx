import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { User } from "@/types";
import { Button } from "@/components/ui/button";

const NavBar = () => {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const { data: user } = useQuery<User | null>({
    queryKey: ['/api/user/current'],
    retry: false,
    staleTime: 300000, // 5 minutes
  });

  const isActive = (path: string) => location === path;
  
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-effect">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <span className="text-neon-purple font-orbitron text-2xl font-bold tracking-wider cursor-pointer">
                  SEO<span className="text-neon-blue">WISE</span>
                </span>
              </Link>
            </div>
            <div className="hidden md:ml-6 md:flex md:space-x-8">
              <Link href="/">
                <span className={`border-b-2 ${isActive('/') ? 'border-neon-purple text-white' : 'border-transparent hover:border-neon-blue text-gray-300 hover:text-white'} px-1 pt-1 font-medium transition-colors cursor-pointer`}>
                  Home
                </span>
              </Link>
              {user && (
                <Link href="/dashboard">
                  <span className={`border-b-2 ${isActive('/dashboard') ? 'border-neon-purple text-white' : 'border-transparent hover:border-neon-blue text-gray-300 hover:text-white'} px-1 pt-1 font-medium transition-colors cursor-pointer`}>
                    Dashboard
                  </span>
                </Link>
              )}
              <Link href="/#features">
                <span className="border-b-2 border-transparent hover:border-neon-blue text-gray-300 hover:text-white px-1 pt-1 font-medium transition-colors cursor-pointer">
                  Features
                </span>
              </Link>
              <Link href="/#pricing">
                <span className="border-b-2 border-transparent hover:border-neon-blue text-gray-300 hover:text-white px-1 pt-1 font-medium transition-colors cursor-pointer">
                  Pricing
                </span>
              </Link>
            </div>
          </div>
          <div className="flex items-center">
            <div className="flex-shrink-0">
              {user ? (
                <Link href="/dashboard">
                  <Button className="bg-gradient-to-r from-neon-purple to-neon-blue text-white shadow-lg hover:shadow-xl neon-button transition">
                    Dashboard
                  </Button>
                </Link>
              ) : (
                <>
                  <Link href="/auth">
                    <Button className="bg-gradient-to-r from-neon-purple to-neon-blue text-white shadow-lg hover:shadow-xl neon-button transition">
                      Sign In
                    </Button>
                  </Link>
                  <Link href="/auth?tab=register">
                    <Button className="ml-4 bg-transparent border border-neon-blue text-white shadow-lg hover:shadow-xl neon-button transition">
                      Start Free Trial
                    </Button>
                  </Link>
                </>
              )}
            </div>
            <div className="ml-3 relative md:hidden">
              <button
                type="button"
                className="text-gray-300 hover:text-white"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                <i className="fas fa-bars text-xl"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden glass-effect">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link href="/">
              <span className={`block px-3 py-2 rounded-md text-base font-medium ${isActive('/') ? 'text-white bg-cyberpunk-card-light' : 'text-gray-300 hover:text-white hover:bg-cyberpunk-card'} cursor-pointer`}>
                Home
              </span>
            </Link>
            {user && (
              <Link href="/dashboard">
                <span className={`block px-3 py-2 rounded-md text-base font-medium ${isActive('/dashboard') ? 'text-white bg-cyberpunk-card-light' : 'text-gray-300 hover:text-white hover:bg-cyberpunk-card'} cursor-pointer`}>
                  Dashboard
                </span>
              </Link>
            )}
            <Link href="/#features">
              <span className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-cyberpunk-card cursor-pointer">
                Features
              </span>
            </Link>
            <Link href="/#pricing">
              <span className="block px-3 py-2 rounded-md text-base font-medium text-gray-300 hover:text-white hover:bg-cyberpunk-card cursor-pointer">
                Pricing
              </span>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default NavBar;
