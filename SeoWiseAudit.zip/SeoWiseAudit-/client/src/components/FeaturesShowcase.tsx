const features = [
  {
    icon: "fas fa-code",
    title: "Technical SEO",
    description: "Analyze meta tags, headers, schema markup, and more",
    items: [
      "Meta tag analysis",
      "Header structure check",
      "Schema markup detection",
      "URL structure analysis"
    ],
    bgFrom: "neon-purple",
    bgTo: "neon-blue"
  },
  {
    icon: "fas fa-file-alt",
    title: "Content Quality",
    description: "Evaluate content depth, relevance, and optimization",
    items: [
      "Keyword usage analysis",
      "Content depth evaluation",
      "Readability assessment",
      "Content freshness check"
    ],
    bgFrom: "neon-green",
    bgTo: "neon-blue"
  },
  {
    icon: "fas fa-tachometer-alt",
    title: "Performance",
    description: "Analyze page speed and core web vitals",
    items: [
      "Page load time analysis",
      "Core Web Vitals assessment",
      "Resource optimization check",
      "Performance bottleneck detection"
    ],
    bgFrom: "neon-blue",
    bgTo: "neon-yellow"
  },
  {
    icon: "fas fa-mobile-alt",
    title: "Mobile Friendliness",
    description: "Check responsive design and mobile optimization",
    items: [
      "Viewport configuration check",
      "Touch target size analysis",
      "Responsive design testing",
      "Mobile-specific issues detection"
    ],
    bgFrom: "neon-yellow",
    bgTo: "neon-purple"
  },
  {
    icon: "fas fa-link",
    title: "Backlink Analysis",
    description: "Evaluate domain authority and backlink profile",
    items: [
      "Domain authority assessment",
      "Backlink quality analysis",
      "Referring domains evaluation",
      "Backlink opportunity identification"
    ],
    bgFrom: "neon-red",
    bgTo: "neon-purple"
  },
  {
    icon: "fas fa-robot",
    title: "AI Recommendations",
    description: "Get intelligent, actionable insights from Mistral AI",
    items: [
      "Prioritized recommendations",
      "Implementation guidelines",
      "Competitive analysis",
      "Custom SEO strategy"
    ],
    bgFrom: "neon-blue",
    bgTo: "neon-green"
  }
];

const FeaturesShowcase = () => {
  return (
    <div id="features" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold font-orbitron mb-2 text-white">Comprehensive <span className="text-neon-blue">Features</span></h2>
        <p className="text-gray-400 max-w-2xl mx-auto">Our tool provides in-depth analysis across all critical SEO factors</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => (
          <div key={index} className="glass-effect rounded-xl p-6 neon-border group hover:bg-cyberpunk-card-light banner-blur">
            <div className={`h-10 w-10 rounded-full bg-gradient-to-r from-${feature.bgFrom} to-${feature.bgTo} p-2 flex items-center justify-center mb-4`}>
              <i className={`${feature.icon} text-white`}></i>
            </div>
            <h3 className="text-xl font-bold font-orbitron text-white mb-2">{feature.title}</h3>
            <p className="text-gray-400 mb-4">{feature.description}</p>
            <ul className="text-gray-300 space-y-2">
              {feature.items.map((item, itemIndex) => (
                <li key={itemIndex} className="flex items-start">
                  <i className="fas fa-check text-neon-green mt-1 mr-2"></i>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FeaturesShowcase;
