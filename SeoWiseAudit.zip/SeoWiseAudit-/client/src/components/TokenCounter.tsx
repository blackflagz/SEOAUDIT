import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { User } from "@/types";

const TokenCounter = () => {
  const { data: user } = useQuery<User | null>({
    queryKey: ['/api/user/current'],
    retry: false,
    staleTime: 300000, // 5 minutes
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
      <div className="glass-effect rounded-xl p-6 neon-border">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="bg-gradient-to-r from-neon-purple to-neon-blue p-px rounded-full mr-4">
              <div className="bg-cyberpunk-card p-3 rounded-full">
                <i className="fas fa-bolt text-neon-yellow text-xl"></i>
              </div>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Your Tokens</p>
              <p className="text-white font-orbitron text-2xl font-bold">
                {user ? user.tokens : 250} {!user && <span className="text-neon-blue text-sm">FREE</span>}
              </p>
            </div>
          </div>
          <div className="flex items-center mb-4 md:mb-0">
            <div className="mr-4 text-right">
              <p className="text-gray-400 text-sm">Basic Audit</p>
              <p className="text-white font-orbitron">100 tokens</p>
            </div>
            <div className="mr-4 text-right">
              <p className="text-gray-400 text-sm">Full Audit</p>
              <p className="text-white font-orbitron">250 tokens</p>
            </div>
            <div className="text-right">
              <p className="text-gray-400 text-sm">AI Analysis</p>
              <p className="text-white font-orbitron">+150 tokens</p>
            </div>
          </div>
          <Button className="bg-cyberpunk-card-light hover:bg-gradient-to-r from-neon-purple to-neon-blue text-white neon-button transition">
            <i className="fas fa-plus mr-2"></i> Buy Tokens
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TokenCounter;
