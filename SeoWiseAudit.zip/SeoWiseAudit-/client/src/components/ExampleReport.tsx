import { Button } from "@/components/ui/button";

const ExampleReport = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
      <div className="glass-effect rounded-xl p-8 neon-border">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6">
          <div>
            <h2 className="text-3xl font-bold font-orbitron text-white">Sample <span className="text-neon-blue">Audit Report</span></h2>
            <p className="text-gray-400">See what your comprehensive SEO audit will look like</p>
          </div>
          <div className="mt-4 lg:mt-0">
            <Button className="bg-cyberpunk-card-light text-white px-4 py-2 rounded-md font-medium hover:bg-cyberpunk-card hover:text-neon-blue transition flex items-center">
              <i className="fas fa-download mr-2"></i> Download Sample PDF
            </Button>
          </div>
        </div>
        
        <div className="bg-cyberpunk-card rounded-xl p-6 border border-cyberpunk-card-light">
          <div className="mb-6">
            <h3 className="text-xl font-bold font-orbitron text-white mb-3">Executive Summary</h3>
            <p className="text-gray-300 mb-4">This SEO audit of Andrej Karpathy's personal website (https://karpathy.ai/) has identified several strengths and opportunities for improvement. The site benefits from excellent performance metrics, high-quality content, and likely strong domain authority due to Karpathy's prominence in the AI field. However, there are significant technical SEO elements missing that could improve search visibility and user experience.</p>
            
            {/* Executive Summary Visualization */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
                <div className="cyberpunk-progress mb-2">
                  <div className="cyberpunk-progress-bar" style={{ width: '92%' }}></div>
                </div>
                <p className="text-2xl font-bold font-orbitron text-neon-green">92<span className="text-lg">/100</span></p>
                <p className="text-gray-400 text-sm">Performance</p>
              </div>
              <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
                <div className="cyberpunk-progress mb-2">
                  <div className="cyberpunk-progress-bar" style={{ width: '45%' }}></div>
                </div>
                <p className="text-2xl font-bold font-orbitron text-neon-yellow">45<span className="text-lg">/100</span></p>
                <p className="text-gray-400 text-sm">Technical SEO</p>
              </div>
              <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
                <div className="cyberpunk-progress mb-2">
                  <div className="cyberpunk-progress-bar" style={{ width: '88%' }}></div>
                </div>
                <p className="text-2xl font-bold font-orbitron text-neon-green">88<span className="text-lg">/100</span></p>
                <p className="text-gray-400 text-sm">Content Quality</p>
              </div>
              <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
                <div className="cyberpunk-progress mb-2">
                  <div className="cyberpunk-progress-bar" style={{ width: '65%' }}></div>
                </div>
                <p className="text-2xl font-bold font-orbitron text-neon-blue">65<span className="text-lg">/100</span></p>
                <p className="text-gray-400 text-sm">Mobile Experience</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {/* Key Strengths */}
            <div>
              <h3 className="text-xl font-bold font-orbitron text-white mb-3">Key Strengths</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-neon-green mt-1 mr-2"></i>
                  <div>
                    <p className="text-white font-medium">Excellent Performance</p>
                    <p className="text-gray-400 text-sm">The site loads extremely quickly (184ms page load time) with minimal render-blocking resources</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-neon-green mt-1 mr-2"></i>
                  <div>
                    <p className="text-white font-medium">High-Quality Content</p>
                    <p className="text-gray-400 text-sm">Content demonstrates deep expertise in AI and machine learning with regular updates</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check-circle text-neon-green mt-1 mr-2"></i>
                  <div>
                    <p className="text-white font-medium">Clean URL Structure</p>
                    <p className="text-gray-400 text-sm">Simple, memorable domain that matches the site owner's name</p>
                  </div>
                </li>
              </ul>
            </div>
            
            {/* Critical Issues */}
            <div>
              <h3 className="text-xl font-bold font-orbitron text-white mb-3">Critical Issues</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <i className="fas fa-exclamation-circle text-neon-red mt-1 mr-2"></i>
                  <div>
                    <p className="text-white font-medium">Missing Meta Description</p>
                    <p className="text-gray-400 text-sm">No meta description tag to improve click-through rates in search results</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-exclamation-circle text-neon-red mt-1 mr-2"></i>
                  <div>
                    <p className="text-white font-medium">No Sitemap.xml</p>
                    <p className="text-gray-400 text-sm">No XML sitemap to help search engines discover and index content</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-exclamation-circle text-neon-red mt-1 mr-2"></i>
                  <div>
                    <p className="text-white font-medium">No Schema Markup</p>
                    <p className="text-gray-400 text-sm">Missing structured data that could enhance search result appearance</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          
          {/* Recommendations Preview */}
          <div>
            <h3 className="text-xl font-bold font-orbitron text-white mb-3">Prioritized Recommendations</h3>
            <div className="bg-cyberpunk-card-light rounded-lg p-4">
              <div className="flex items-center mb-2">
                <div className="h-6 w-6 rounded-full bg-gradient-to-r from-neon-purple to-neon-blue flex items-center justify-center mr-2">
                  <span className="text-xs font-bold">1</span>
                </div>
                <p className="text-white font-medium">Add Meta Description</p>
              </div>
              <div className="ml-8 mb-4">
                <p className="text-gray-300 text-sm mb-2">Create a compelling meta description that includes primary keywords and value proposition</p>
                <div className="bg-cyberpunk-bg rounded-md p-3 text-gray-300 text-sm font-mono">
                  &lt;meta name="description" content="Personal website of Andrej Karpathy, AI researcher and former Director of AI at Tesla, featuring insights on deep learning, neural networks, and artificial intelligence."&gt;
                </div>
              </div>
              
              <div className="flex items-center mb-2">
                <div className="h-6 w-6 rounded-full bg-gradient-to-r from-neon-purple to-neon-blue flex items-center justify-center mr-2">
                  <span className="text-xs font-bold">2</span>
                </div>
                <p className="text-white font-medium">Implement XML Sitemap</p>
              </div>
              <div className="ml-8">
                <p className="text-gray-300 text-sm">Create and submit a sitemap.xml file to search engines to improve content discovery and indexing</p>
              </div>
            </div>
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-gray-400">This is just a preview. Full reports include detailed analysis and implementation guidance for all issues.</p>
            <Button className="mt-4 bg-gradient-to-r from-neon-purple to-neon-blue text-white px-6 py-2 rounded-md font-medium shadow-lg hover:shadow-xl neon-button transition">
              Try a Real Audit Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExampleReport;
