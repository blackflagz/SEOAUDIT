import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Package } from "@/types";

const packages: Package[] = [
  {
    id: 1,
    name: "Starter Package",
    description: "Perfect for small websites or single page audits",
    price: 3.49,
    tokens: 650,
    popular: false
  },
  {
    id: 2,
    name: "Pro Package",
    description: "Ideal for medium-sized websites with multiple pages",
    price: 9.99,
    tokens: 2000,
    popular: true
  },
  {
    id: 3,
    name: "Enterprise Package",
    description: "Best for large websites or frequent audits",
    price: 19.99,
    tokens: 5000,
    popular: false
  }
];

const Pricing = () => {
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
  const { toast } = useToast();

  const { mutate: createPaymentIntent, isPending } = useMutation({
    mutationFn: async (packageId: number) => {
      const response = await apiRequest("POST", "/api/payment/create-intent", { packageId });
      return response.json();
    },
    onSuccess: (data) => {
      // Here you would typically redirect to a payment page or open a payment modal
      toast({
        title: "Payment initiated",
        description: `You've selected the ${selectedPackage?.name} package. Redirecting to payment...`,
      });
      
      // Redirect to payment page or process payment
      // window.location.href = data.url;
    },
    onError: (error) => {
      toast({
        title: "Payment error",
        description: error.message || "There was an error processing your payment request.",
        variant: "destructive",
      });
    }
  });

  const handlePurchase = (pkg: Package) => {
    setSelectedPackage(pkg);
    createPaymentIntent(pkg.id);
  };

  const handleFreeTrial = () => {
    // Get the current user
    apiRequest("GET", "/api/user/current")
      .then(response => {
        if (response.status === 401) {
          // Not logged in, redirect to auth page with trial=true parameter
          window.location.href = '/auth?trial=true';
          return null;
        }
        return response.json();
      })
      .then(user => {
        // If user is logged in (not redirected), activate free trial
        if (user) {
          return apiRequest("POST", "/api/users/free-trial", {});
        }
      })
      .then(response => {
        if (response) {
          toast({
            title: "Free trial activated",
            description: "Your account has been credited with 250 tokens to start your free trial!",
          });
        }
      })
      .catch((error) => {
        toast({
          title: "Error",
          description: error.message || "Failed to activate free trial.",
          variant: "destructive",
        });
      });
  };

  return (
    <div id="pricing" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold font-orbitron mb-2 text-white">Simple <span className="text-neon-blue">Token Pricing</span></h2>
        <p className="text-gray-400 max-w-2xl mx-auto">Pay only for what you need, when you need it. No subscriptions or commitments.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {packages.map((pkg) => (
          <div 
            key={pkg.id} 
            className={`${pkg.popular ? 'glass-effect rounded-xl p-6 border-2 border-neon-blue relative overflow-hidden transform scale-105 group' : 'glass-effect rounded-xl p-6 neon-border relative overflow-hidden group'}`}
          >
            <div className={`absolute top-0 right-0 bg-gradient-to-l ${pkg.popular ? 'from-neon-blue' : pkg.id === 1 ? 'from-neon-purple' : 'from-neon-green'} to-transparent py-1 px-4 rounded-bl-lg text-xs font-medium ${!pkg.popular && 'opacity-80'}`}>
              {pkg.popular ? 'POPULAR' : pkg.id === 1 ? 'BASIC' : 'ADVANCED'}
            </div>
            <div className="pt-6">
              <h3 className="text-xl font-bold font-orbitron text-white mb-2">{pkg.name}</h3>
              <div className="flex items-end mb-4">
                <span className="text-3xl font-bold text-white">${pkg.price.toFixed(2)}</span>
                <span className="text-gray-400 ml-2">/ one-time</span>
              </div>
              <p className="text-gray-400 mb-6">{pkg.description}</p>
              
              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <div className="w-6 h-6 rounded-full bg-cyberpunk-card-light flex items-center justify-center mr-2">
                    <i className="fas fa-bolt text-neon-yellow text-xs"></i>
                  </div>
                  <p className="text-white font-orbitron">{pkg.tokens.toLocaleString()} Tokens</p>
                </div>
                <p className="text-gray-400 text-sm">
                  {pkg.id === 1 && "Enough for 6 basic audits or 3 full audits"}
                  {pkg.id === 2 && "Enough for 20 basic audits or 8 full audits with AI"}
                  {pkg.id === 3 && "Enough for 50 basic audits or 20 full audits with AI"}
                </p>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <i className="fas fa-check text-neon-green mt-1 mr-2"></i>
                  <span className="text-gray-300">Technical SEO Analysis</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check text-neon-green mt-1 mr-2"></i>
                  <span className="text-gray-300">Content Quality Evaluation</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-check text-neon-green mt-1 mr-2"></i>
                  <span className="text-gray-300">Performance Metrics</span>
                </li>
                <li className="flex items-start">
                  {pkg.id === 1 ? (
                    <>
                      <i className="fas fa-times text-gray-500 mt-1 mr-2"></i>
                      <span className="text-gray-500">AI-Powered Recommendations</span>
                    </>
                  ) : (
                    <>
                      <i className="fas fa-check text-neon-green mt-1 mr-2"></i>
                      <span className="text-gray-300">AI-Powered Recommendations</span>
                    </>
                  )}
                </li>
                <li className="flex items-start">
                  {pkg.id === 1 ? (
                    <>
                      <i className="fas fa-times text-gray-500 mt-1 mr-2"></i>
                      <span className="text-gray-500">Keyword Analysis</span>
                    </>
                  ) : (
                    <>
                      <i className="fas fa-check text-neon-green mt-1 mr-2"></i>
                      <span className="text-gray-300">Keyword Analysis</span>
                    </>
                  )}
                </li>
                {pkg.id === 3 && (
                  <>
                    <li className="flex items-start">
                      <i className="fas fa-check text-neon-green mt-1 mr-2"></i>
                      <span className="text-gray-300">Competitor Analysis</span>
                    </li>
                    <li className="flex items-start">
                      <i className="fas fa-check text-neon-green mt-1 mr-2"></i>
                      <span className="text-gray-300">Priority Support</span>
                    </li>
                  </>
                )}
              </ul>
              
              <Button
                onClick={() => handlePurchase(pkg)}
                disabled={isPending && selectedPackage?.id === pkg.id}
                className={`w-full ${pkg.popular ? 'bg-gradient-to-r from-neon-purple to-neon-blue' : pkg.id === 1 ? 'bg-cyberpunk-card-light hover:bg-gradient-to-r hover:from-neon-purple hover:to-neon-blue' : 'bg-cyberpunk-card-light hover:bg-gradient-to-r hover:from-neon-green hover:to-neon-blue'} text-white py-2 px-4 rounded-md font-medium neon-button transition ${pkg.popular ? '' : 'group-hover:bg-gradient-to-r group-hover:from-neon-purple group-hover:to-neon-blue'}`}
              >
                {isPending && selectedPackage?.id === pkg.id ? (
                  <span className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </span>
                ) : (
                  'Purchase Tokens'
                )}
              </Button>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-12 text-center">
        <p className="text-gray-400 mb-4">Not sure which package is right for you? Start with a free trial!</p>
        <Button 
          onClick={handleFreeTrial}
          className="bg-transparent border border-neon-blue text-white px-6 py-3 rounded-md font-medium hover:bg-cyberpunk-card-light neon-button transition"
        >
          Start Free Trial (250 Tokens)
        </Button>
      </div>
    </div>
  );
};

export default Pricing;
