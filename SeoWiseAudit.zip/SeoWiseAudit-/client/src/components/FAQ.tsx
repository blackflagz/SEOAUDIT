import { useState } from "react";
import { cn } from "@/lib/utils";

interface FAQItem {
  question: string;
  answer: string;
}

const faqItems: FAQItem[] = [
  {
    question: "How does the token system work?",
    answer: "Tokens are our virtual currency that you can use to purchase audits. Different audit types cost different amounts of tokens. For example, a basic audit costs 100 tokens, while a full audit with AI analysis costs 400 tokens. You can purchase token packages based on your needs, and they never expire."
  },
  {
    question: "What's included in the free trial?",
    answer: "The free trial gives you 250 tokens to test our service. This is enough for 2 basic audits or 1 full audit without AI analysis. The free trial provides access to all features except AI-powered recommendations, giving you a good sense of our tool's capabilities before purchasing."
  },
  {
    question: "How is SEOWISE different from other SEO tools?",
    answer: "SEOWISE differentiates itself with a pay-as-you-go token system instead of expensive monthly subscriptions. We also leverage the Mistral Large AI model for enhanced analysis and recommendations that go beyond basic rule-based checks. Our tool provides comprehensive, actionable reports with implementation guidance, making SEO improvements straightforward even for non-experts."
  },
  {
    question: "Can I audit websites I don't own?",
    answer: "Yes, you can audit any publicly accessible website. This is useful for competitive analysis or evaluating potential clients' websites. However, some features like schema validation require deeper access and may provide limited results for sites you don't control."
  },
  {
    question: "How often should I run SEO audits?",
    answer: "For most websites, we recommend running a full audit quarterly and basic audits monthly. However, this depends on your website's size, how frequently you update content, and your competitive landscape. After making significant changes to your site, it's also advisable to run a focused audit to ensure everything is optimized."
  }
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold font-orbitron mb-2 text-white">Frequently Asked <span className="text-neon-blue">Questions</span></h2>
        <p className="text-gray-400 max-w-2xl mx-auto">Everything you need to know about our SEO audit tool</p>
      </div>
      
      <div className="space-y-6">
        {faqItems.map((item, index) => (
          <div key={index} className="glass-effect rounded-xl neon-border overflow-hidden">
            <button 
              className="w-full text-left px-6 py-4 focus:outline-none flex justify-between items-center"
              onClick={() => toggleFAQ(index)}
            >
              <span className="text-white font-medium">{item.question}</span>
              <i className={`fas ${openIndex === index ? 'fa-minus' : 'fa-plus'} text-neon-blue`}></i>
            </button>
            <div 
              className={cn(
                "px-6 py-4 bg-cyberpunk-card-light border-t border-cyberpunk-bg",
                openIndex === index ? "block" : "hidden"
              )}
            >
              <p className="text-gray-300">{item.answer}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQ;
