import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const HeroSection = () => {
  return (
    <div className="pt-24 pb-8 md:pt-36 md:pb-16 tech-pattern">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl tracking-tight font-extrabold text-white sm:text-5xl md:text-6xl font-orbitron">
            <span className="block xl:inline bg-clip-text text-transparent bg-gradient-to-r from-neon-purple to-neon-blue">Premium SEO Audit</span>
            <span className="block mt-2">Powered by AI</span>
          </h1>
          <p className="mt-3 max-w-md mx-auto text-lg text-gray-300 sm:text-xl md:mt-5 md:max-w-3xl">
            Instant, in-depth SEO analysis with actionable recommendations to boost your search rankings. Pay-as-you-go, no subscriptions required.
          </p>
          <div className="mt-10 flex justify-center">
            <div className="rounded-md shadow">
              <Link href="#audit-tool">
                <Button className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-gradient-to-r from-neon-purple to-neon-blue hover:from-neon-purple hover:to-neon-blue neon-button md:py-4 md:text-lg md:px-10">
                  Start Free Audit
                </Button>
              </Link>
            </div>
            <div className="ml-3 rounded-md shadow">
              <Link href="#features">
                <Button className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-cyberpunk-card hover:bg-cyberpunk-card-light md:py-4 md:text-lg md:px-10 neon-border">
                  See Features
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
