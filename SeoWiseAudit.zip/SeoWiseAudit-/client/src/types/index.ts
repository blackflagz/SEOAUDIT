export interface User {
  id: number;
  username: string;
  email: string;
  tokens: number;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface InsertUser {
  username: string;
  email: string;
  password: string;
  tokens?: number;
}

export enum AuditType {
  BASIC = 'basic',
  FULL = 'full'
}

export enum AuditStatus {
  PENDING = 'pending',
  RUNNING = 'running',
  COMPLETED = 'completed',
  FAILED = 'failed'
}

export interface SeoAudit {
  id: number;
  userId: number;
  url: string;
  type: AuditType;
  useAI: boolean;
  status: AuditStatus;
  score: number | null;
  createdAt: Date;
  completedAt: Date | null;
}

export interface InsertSeoAudit {
  userId: number;
  url: string;
  type: AuditType;
  useAI: boolean;
  status?: AuditStatus;
  score?: number | null;
}

export interface SeoAuditReport {
  id: number;
  auditId: number;
  technicalSeoScore: number;
  contentQualityScore: number;
  performanceScore: number;
  mobileFriendlinessScore: number;
  backlinksScore: number | null;
  strengths: string[];
  criticalIssues: string[];
  secondaryIssues: string[];
  recommendations: SeoRecommendation[];
}

export interface SeoRecommendation {
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  implementationGuide?: string;
}

export interface Package {
  id: number;
  name: string;
  description: string;
  price: number;
  tokens: number;
  popular?: boolean;
}

export interface PaymentIntent {
  id: string;
  packageId: number;
  userId: number;
  amount: number;
  status: 'pending' | 'succeeded' | 'failed';
  createdAt: Date;
}
