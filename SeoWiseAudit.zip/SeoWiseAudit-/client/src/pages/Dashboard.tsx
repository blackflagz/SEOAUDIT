import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { SeoAudit, User } from "@/types";
import { useToast } from "@/hooks/use-toast";

const Dashboard = () => {
  const { toast } = useToast();
  const [isClient, setIsClient] = useState(false);

  // Make sure this only runs on client-side
  useEffect(() => {
    setIsClient(true);
  }, []);

  const { data: user, isLoading: isLoadingUser, error: userError } = useQuery<User>({
    queryKey: ['/api/user/current'],
    retry: false,
    staleTime: 300000, // 5 minutes
  });

  const { data: audits, isLoading: isLoadingAudits } = useQuery<SeoAudit[]>({
    queryKey: ['/api/audits'],
    enabled: isClient && !!user,
    staleTime: 60000, // 1 minute
  });

  if (isLoadingUser) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-neon-purple"></div>
      </div>
    );
  }

  if (userError || !user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-3xl font-orbitron text-white mb-4">Access Denied</h1>
        <p className="text-gray-400 mb-6">You need to sign in to access the dashboard</p>
        <Link href="/">
          <Button className="bg-gradient-to-r from-neon-purple to-neon-blue text-white px-6 py-3 rounded-md font-medium neon-button transition">
            Go to Homepage
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <NavBar />
      
      <div className="pt-24 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold font-orbitron text-white">Welcome, {user.username}</h1>
            <p className="text-gray-400">Manage your SEO audits and reports</p>
          </div>
          <div className="mt-4 md:mt-0 flex items-center">
            <div className="bg-gradient-to-r from-neon-purple to-neon-blue p-px rounded-full mr-4">
              <div className="bg-cyberpunk-card p-3 rounded-full">
                <i className="fas fa-bolt text-neon-yellow text-xl"></i>
              </div>
            </div>
            <div>
              <p className="text-gray-400 text-sm">Your Tokens</p>
              <p className="text-white font-orbitron text-2xl font-bold">{user.tokens}</p>
            </div>
          </div>
        </div>
        
        {/* Recent Audits Section */}
        <div className="glass-effect rounded-xl p-8 neon-border mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-orbitron text-white">Recent Audits</h2>
            <Link href="/#audit-tool">
              <Button className="bg-gradient-to-r from-neon-purple to-neon-blue text-white px-4 py-2 rounded-md font-medium neon-button transition">
                <i className="fas fa-plus mr-2"></i> New Audit
              </Button>
            </Link>
          </div>
          
          {isLoadingAudits ? (
            <div className="flex justify-center py-10">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-neon-blue"></div>
            </div>
          ) : audits && audits.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {audits.map((audit) => (
                <Card key={audit.id} className="bg-cyberpunk-card border-cyberpunk-card-light hover:border-neon-blue transition-colors">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg text-white font-orbitron truncate">{audit.url}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center">
                        <span className={`h-2 w-2 rounded-full ${
                          audit.status === 'completed' ? 'bg-neon-green' : 
                          audit.status === 'running' ? 'bg-neon-yellow animate-pulse' : 
                          audit.status === 'failed' ? 'bg-neon-red' : 'bg-gray-400'
                        } mr-2`}></span>
                        <span className="text-gray-300 capitalize">{audit.status}</span>
                      </div>
                      <span className="text-gray-400 text-sm">
                        {new Date(audit.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    
                    {audit.score !== null && (
                      <div className="mb-4">
                        <div className="cyberpunk-progress">
                          <div className="cyberpunk-progress-bar" style={{ width: `${audit.score}%` }}></div>
                        </div>
                        <div className="flex justify-between mt-1">
                          <span className="text-sm text-gray-400">SEO Score</span>
                          <span className={`text-sm font-medium ${
                            audit.score >= 70 ? 'text-neon-green' : 
                            audit.score >= 40 ? 'text-neon-yellow' : 
                            'text-neon-red'
                          }`}>{audit.score}/100</span>
                        </div>
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <div className="flex space-x-2">
                        <span className="px-2 py-1 bg-cyberpunk-bg text-xs rounded-md text-gray-300">
                          {audit.type === 'basic' ? 'Basic' : 'Full'}
                        </span>
                        {audit.useAI && (
                          <span className="px-2 py-1 bg-cyberpunk-bg text-xs rounded-md text-neon-green flex items-center">
                            <i className="fas fa-robot mr-1"></i> AI
                          </span>
                        )}
                      </div>
                      
                      {audit.status === 'completed' && (
                        <Link href={`/report/${audit.id}`}>
                          <Button className="bg-transparent border border-neon-blue text-white hover:bg-cyberpunk-card-light text-sm px-3 py-1 rounded">
                            View Report
                          </Button>
                        </Link>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="bg-cyberpunk-card-light rounded-xl p-10 text-center">
              <i className="fas fa-search text-4xl text-gray-500 mb-4"></i>
              <p className="text-white text-lg mb-2">No audits yet</p>
              <p className="text-gray-400 mb-6">Run your first SEO audit to get insights and recommendations</p>
              <Link href="/#audit-tool">
                <Button className="bg-gradient-to-r from-neon-purple to-neon-blue text-white px-6 py-2 rounded-md font-medium neon-button transition">
                  Start Your First Audit
                </Button>
              </Link>
            </div>
          )}
        </div>
        
        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-cyberpunk-card border-cyberpunk-card-light hover:border-neon-blue transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-gradient-to-r from-neon-purple to-neon-blue p-2 flex items-center justify-center mr-3">
                  <i className="fas fa-bolt text-white"></i>
                </div>
                <h3 className="text-lg font-orbitron text-white">Buy Tokens</h3>
              </div>
              <p className="text-gray-400 mb-4">Need more audits? Purchase token packages for your needs.</p>
              <Link href="/#pricing">
                <Button className="w-full bg-transparent border border-neon-blue text-white hover:bg-cyberpunk-card-light neon-button transition">
                  View Pricing
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          <Card className="bg-cyberpunk-card border-cyberpunk-card-light hover:border-neon-blue transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-gradient-to-r from-neon-blue to-neon-green p-2 flex items-center justify-center mr-3">
                  <i className="fas fa-book text-white"></i>
                </div>
                <h3 className="text-lg font-orbitron text-white">SEO Guide</h3>
              </div>
              <p className="text-gray-400 mb-4">Learn about SEO best practices and how to implement our recommendations.</p>
              <Button className="w-full bg-transparent border border-neon-blue text-white hover:bg-cyberpunk-card-light neon-button transition">
                Read Guide
              </Button>
            </CardContent>
          </Card>
          
          <Card className="bg-cyberpunk-card border-cyberpunk-card-light hover:border-neon-blue transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center mb-4">
                <div className="h-10 w-10 rounded-full bg-gradient-to-r from-neon-yellow to-neon-purple p-2 flex items-center justify-center mr-3">
                  <i className="fas fa-headset text-white"></i>
                </div>
                <h3 className="text-lg font-orbitron text-white">Support</h3>
              </div>
              <p className="text-gray-400 mb-4">Need help? Our team is ready to assist you with any questions.</p>
              <Button className="w-full bg-transparent border border-neon-blue text-white hover:bg-cyberpunk-card-light neon-button transition">
                Contact Support
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default Dashboard;
