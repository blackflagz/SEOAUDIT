import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import NavBar from "@/components/NavBar";
import TokenCounter from "@/components/TokenCounter";
import { Separator } from "@/components/ui/separator";
import { AlertCircle, Loader2, CheckCircle2, ChevronDown, ChevronUp } from "lucide-react";

const AdvancedTools = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("content-optimization");
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  
  // Content Optimization States
  const [contentOptUrl, setContentOptUrl] = useState<string>("");
  const [contentOptKeywords, setContentOptKeywords] = useState<string>("");
  const [contentOptResult, setContentOptResult] = useState<any>(null);
  
  // Content Brief States
  const [briefTopic, setBriefTopic] = useState<string>("");
  const [briefKeywords, setBriefKeywords] = useState<string>("");
  const [briefCompetitors, setBriefCompetitors] = useState<string>("");
  const [briefResult, setBriefResult] = useState<any>(null);
  
  // Competitor Analysis States
  const [compUrl, setCompUrl] = useState<string>("");
  const [compCompetitors, setCompCompetitors] = useState<string>("");
  const [compResult, setCompResult] = useState<any>(null);
  
  // Keyword Gap Analysis States
  const [keywordUrl, setKeywordUrl] = useState<string>("");
  const [keywordCompetitors, setKeywordCompetitors] = useState<string>("");
  const [keywordResult, setKeywordResult] = useState<any>(null);
  
  // Content Optimization Mutation
  const contentOptimizationMutation = useMutation({
    mutationFn: async () => {
      const keywordsArray = contentOptKeywords
        .split(",")
        .map(k => k.trim())
        .filter(k => k !== "");
      
      const res = await apiRequest("POST", "/api/content-optimization", {
        url: contentOptUrl,
        keywords: keywordsArray
      });
      return res.json();
    },
    onSuccess: (data) => {
      setContentOptResult(data);
      toast({
        title: "Analysis Complete",
        description: "Content optimization analysis finished successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error.message || "There was an error processing your request",
        variant: "destructive",
      });
    }
  });
  
  // Content Brief Mutation
  const contentBriefMutation = useMutation({
    mutationFn: async () => {
      const keywordsArray = briefKeywords
        .split(",")
        .map(k => k.trim())
        .filter(k => k !== "");
      
      const competitorsArray = briefCompetitors
        .split("\n")
        .map(c => c.trim())
        .filter(c => c !== "");
      
      const res = await apiRequest("POST", "/api/content-brief", {
        topic: briefTopic,
        keywords: keywordsArray,
        competitors: competitorsArray.length > 0 ? competitorsArray : undefined
      });
      return res.json();
    },
    onSuccess: (data) => {
      setBriefResult(data);
      toast({
        title: "Brief Generated",
        description: "Content brief was generated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Brief Generation Failed",
        description: error.message || "There was an error processing your request",
        variant: "destructive",
      });
    }
  });
  
  // Competitor Analysis Mutation
  const competitorAnalysisMutation = useMutation({
    mutationFn: async () => {
      const competitorsArray = compCompetitors
        .split("\n")
        .map(c => c.trim())
        .filter(c => c !== "");
      
      if (competitorsArray.length === 0) {
        throw new Error("At least one competitor URL is required");
      }
      
      const res = await apiRequest("POST", "/api/competitor-analysis", {
        url: compUrl,
        competitors: competitorsArray
      });
      return res.json();
    },
    onSuccess: (data) => {
      setCompResult(data);
      toast({
        title: "Analysis Complete",
        description: "Competitor analysis finished successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error.message || "There was an error processing your request",
        variant: "destructive",
      });
    }
  });
  
  // Keyword Gap Analysis Mutation
  const keywordGapMutation = useMutation({
    mutationFn: async () => {
      const competitorsArray = keywordCompetitors
        .split("\n")
        .map(c => c.trim())
        .filter(c => c !== "");
      
      if (competitorsArray.length === 0) {
        throw new Error("At least one competitor URL is required");
      }
      
      const res = await apiRequest("POST", "/api/keyword-gap", {
        url: keywordUrl,
        competitors: competitorsArray
      });
      return res.json();
    },
    onSuccess: (data) => {
      setKeywordResult(data);
      toast({
        title: "Analysis Complete",
        description: "Keyword gap analysis finished successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error.message || "There was an error processing your request",
        variant: "destructive",
      });
    }
  });
  
  const toggleSection = (section: string) => {
    setExpanded(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };
  
  const isPending = contentOptimizationMutation.isPending || 
                   contentBriefMutation.isPending || 
                   competitorAnalysisMutation.isPending || 
                   keywordGapMutation.isPending;
  
  return (
    <div className="min-h-screen bg-cyberpunk-bg">
      <NavBar />
      
      <div className="container mx-auto px-4 py-20">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold font-orbitron text-white">
            Advanced <span className="text-neon-blue">SEO</span> <span className="text-neon-purple">Tools</span>
          </h1>
          <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
            Leverage AI-powered tools to gain deeper insights and improve your SEO strategy
          </p>
        </div>
        
        {user && (
          <div className="flex justify-center mb-8">
            <TokenCounter tokens={user.tokens} />
          </div>
        )}
        
        <div className="glass-effect rounded-xl p-8 neon-border">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 md:grid-cols-4 mb-8">
              <TabsTrigger value="content-optimization" className="text-sm md:text-base">
                Content Optimization
                <Badge className="ml-2 bg-neon-purple/30 text-white text-xs">50 tokens</Badge>
              </TabsTrigger>
              <TabsTrigger value="content-brief" className="text-sm md:text-base">
                AI Content Brief
                <Badge className="ml-2 bg-neon-purple/30 text-white text-xs">75 tokens</Badge>
              </TabsTrigger>
              <TabsTrigger value="competitor-analysis" className="text-sm md:text-base">
                Competitor Analysis
                <Badge className="ml-2 bg-neon-purple/30 text-white text-xs">100 tokens</Badge>
              </TabsTrigger>
              <TabsTrigger value="keyword-gap" className="text-sm md:text-base">
                Keyword Gap
                <Badge className="ml-2 bg-neon-purple/30 text-white text-xs">75 tokens</Badge>
              </TabsTrigger>
            </TabsList>
            
            {/* Content Optimization Tab */}
            <TabsContent value="content-optimization">
              <div className="space-y-6">
                <div className="text-white">
                  <h2 className="text-2xl font-bold mb-3 font-orbitron">Content Optimization Analysis</h2>
                  <p className="text-gray-400 mb-6">
                    Analyze your content's performance against target keywords and get detailed optimization recommendations.
                  </p>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="content-url">URL to Analyze</Label>
                      <Input
                        id="content-url"
                        placeholder="https://example.com/page-to-analyze"
                        value={contentOptUrl}
                        onChange={(e) => setContentOptUrl(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="content-keywords">Target Keywords (comma separated)</Label>
                      <Textarea
                        id="content-keywords"
                        placeholder="keyword one, keyword two, long tail keyword example"
                        value={contentOptKeywords}
                        onChange={(e) => setContentOptKeywords(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                      />
                    </div>
                    
                    <Button
                      onClick={() => contentOptimizationMutation.mutate()}
                      disabled={!contentOptUrl || !contentOptKeywords || isPending}
                      className="w-full bg-gradient-to-r from-neon-purple to-neon-blue text-white py-3 px-4 rounded-md font-medium shadow-lg hover:shadow-xl neon-button transition flex items-center justify-center"
                    >
                      {contentOptimizationMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Analyzing Content...
                        </>
                      ) : (
                        'Analyze Content (50 Tokens)'
                      )}
                    </Button>
                  </div>
                </div>
                
                {contentOptResult && (
                  <div className="mt-8">
                    <Card className="bg-cyberpunk-card border-neon-blue">
                      <CardHeader>
                        <CardTitle className="text-white">Content Optimization Results</CardTitle>
                        {contentOptResult.overview && (
                          <CardDescription className="text-gray-300">{contentOptResult.overview}</CardDescription>
                        )}
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {contentOptResult.readabilityScore && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-2">Readability Score</h3>
                            <div className="w-full bg-cyberpunk-card-light rounded-full h-6">
                              <div
                                className="bg-gradient-to-r from-neon-red to-neon-green h-6 rounded-full flex items-center justify-center text-xs font-semibold"
                                style={{
                                  width: `${Math.min(100, Math.max(0, contentOptResult.readabilityScore))}%`
                                }}
                              >
                                {contentOptResult.readabilityScore}/100
                              </div>
                            </div>
                          </div>
                        )}
                        
                        {contentOptResult.keywordAnalysis && (
                          <div>
                            <div 
                              className="flex justify-between items-center cursor-pointer"
                              onClick={() => toggleSection('keyword')}
                            >
                              <h3 className="text-lg font-semibold text-white">Keyword Analysis</h3>
                              {expanded.keyword ? <ChevronUp className="h-5 w-5 text-gray-400" /> : <ChevronDown className="h-5 w-5 text-gray-400" />}
                            </div>
                            {expanded.keyword && (
                              <div className="mt-2 space-y-3 text-gray-300">
                                <div>
                                  <h4 className="text-neon-blue font-medium">Primary Keywords</h4>
                                  <p>{contentOptResult.keywordAnalysis.primary}</p>
                                </div>
                                <div>
                                  <h4 className="text-neon-blue font-medium">Secondary Keywords</h4>
                                  <p>{contentOptResult.keywordAnalysis.secondary}</p>
                                </div>
                                <div>
                                  <h4 className="text-neon-blue font-medium">Keyword Gaps</h4>
                                  <p>{contentOptResult.keywordAnalysis.gaps}</p>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                        
                        {contentOptResult.contentStructure && (
                          <div>
                            <div 
                              className="flex justify-between items-center cursor-pointer"
                              onClick={() => toggleSection('structure')}
                            >
                              <h3 className="text-lg font-semibold text-white">Content Structure</h3>
                              {expanded.structure ? <ChevronUp className="h-5 w-5 text-gray-400" /> : <ChevronDown className="h-5 w-5 text-gray-400" />}
                            </div>
                            {expanded.structure && (
                              <div className="mt-2 space-y-3 text-gray-300">
                                <div>
                                  <h4 className="text-neon-blue font-medium">Assessment</h4>
                                  <p>{contentOptResult.contentStructure.assessment}</p>
                                </div>
                                <div>
                                  <h4 className="text-neon-blue font-medium">Recommendations</h4>
                                  <p>{contentOptResult.contentStructure.recommendations}</p>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                        
                        {contentOptResult.optimizationRecommendations && contentOptResult.optimizationRecommendations.length > 0 && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-4">Recommendations</h3>
                            <div className="space-y-4">
                              {contentOptResult.optimizationRecommendations.map((rec: any, index: number) => (
                                <div key={index} className="bg-cyberpunk-card-light p-4 rounded-lg border border-gray-700">
                                  <div className="flex items-start">
                                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mr-3 ${
                                      rec.priority === 'high' ? 'bg-neon-red/20 text-neon-red' : 
                                      rec.priority === 'medium' ? 'bg-amber-500/20 text-amber-500' : 
                                      'bg-neon-green/20 text-neon-green'
                                    }`}>
                                      <AlertCircle className="w-4 h-4" />
                                    </div>
                                    <div>
                                      <h4 className="text-white font-medium flex items-center">
                                        {rec.title}
                                        <Badge className={`ml-2 text-xs ${
                                          rec.priority === 'high' ? 'bg-neon-red/20 text-neon-red' : 
                                          rec.priority === 'medium' ? 'bg-amber-500/20 text-amber-500' : 
                                          'bg-neon-green/20 text-neon-green'
                                        }`}>
                                          {rec.priority}
                                        </Badge>
                                      </h4>
                                      <p className="text-gray-300 mt-1">{rec.description}</p>
                                      {rec.implementation && (
                                        <div className="mt-2">
                                          <h5 className="text-neon-blue text-sm font-medium">Implementation:</h5>
                                          <p className="text-gray-400 text-sm">{rec.implementation}</p>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            </TabsContent>
            
            {/* Content Brief Tab */}
            <TabsContent value="content-brief">
              <div className="space-y-6">
                <div className="text-white">
                  <h2 className="text-2xl font-bold mb-3 font-orbitron">AI Content Brief Generator</h2>
                  <p className="text-gray-400 mb-6">
                    Create comprehensive content briefs for new articles with target keywords and competitor analysis.
                  </p>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="brief-topic">Content Topic</Label>
                      <Input
                        id="brief-topic"
                        placeholder="Enter your main content topic"
                        value={briefTopic}
                        onChange={(e) => setBriefTopic(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="brief-keywords">Target Keywords (comma separated)</Label>
                      <Textarea
                        id="brief-keywords"
                        placeholder="seo tools, ai seo tools, content optimization"
                        value={briefKeywords}
                        onChange={(e) => setBriefKeywords(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="brief-competitors">Competitor URLs (optional, one per line)</Label>
                      <Textarea
                        id="brief-competitors"
                        placeholder="https://competitor1.com/relevant-page
https://competitor2.com/relevant-page"
                        value={briefCompetitors}
                        onChange={(e) => setBriefCompetitors(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple h-24"
                      />
                    </div>
                    
                    <Button
                      onClick={() => contentBriefMutation.mutate()}
                      disabled={!briefTopic || !briefKeywords || isPending}
                      className="w-full bg-gradient-to-r from-neon-purple to-neon-blue text-white py-3 px-4 rounded-md font-medium shadow-lg hover:shadow-xl neon-button transition flex items-center justify-center"
                    >
                      {contentBriefMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Generating Brief...
                        </>
                      ) : (
                        'Generate Content Brief (75 Tokens)'
                      )}
                    </Button>
                  </div>
                </div>
                
                {briefResult && (
                  <div className="mt-8">
                    <Card className="bg-cyberpunk-card border-neon-blue">
                      <CardHeader>
                        <CardTitle className="text-white">
                          {briefResult.title || "Content Brief Results"}
                        </CardTitle>
                        {briefResult.metaDescription && (
                          <CardDescription className="text-gray-300">{briefResult.metaDescription}</CardDescription>
                        )}
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {briefResult.targetWordCount && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-2">Target Word Count</h3>
                            <p className="text-gray-300">{briefResult.targetWordCount} words</p>
                          </div>
                        )}
                        
                        {briefResult.keywordStrategy && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-2">Keyword Strategy</h3>
                            <div className="space-y-2">
                              {briefResult.keywordStrategy.primary && (
                                <div>
                                  <h4 className="text-neon-blue text-sm font-medium">Primary Keyword:</h4>
                                  <p className="text-gray-300">{briefResult.keywordStrategy.primary}</p>
                                </div>
                              )}
                              
                              {briefResult.keywordStrategy.secondary && briefResult.keywordStrategy.secondary.length > 0 && (
                                <div>
                                  <h4 className="text-neon-blue text-sm font-medium">Secondary Keywords:</h4>
                                  <div className="flex flex-wrap gap-2 mt-1">
                                    {briefResult.keywordStrategy.secondary.map((kw: string, i: number) => (
                                      <Badge key={i} className="bg-neon-purple/20 text-neon-purple">{kw}</Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                              
                              {briefResult.keywordStrategy.semantic && briefResult.keywordStrategy.semantic.length > 0 && (
                                <div>
                                  <h4 className="text-neon-blue text-sm font-medium">Semantic Keywords:</h4>
                                  <div className="flex flex-wrap gap-2 mt-1">
                                    {briefResult.keywordStrategy.semantic.map((kw: string, i: number) => (
                                      <Badge key={i} className="bg-neon-blue/20 text-neon-blue">{kw}</Badge>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {briefResult.contentStructure && briefResult.contentStructure.length > 0 && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-3">Content Structure</h3>
                            <div className="space-y-4">
                              {briefResult.contentStructure.map((section: any, index: number) => (
                                <div key={index} className="bg-cyberpunk-card-light p-4 rounded-lg border border-gray-700">
                                  <h4 className="text-white font-medium">{section.heading}</h4>
                                  
                                  {section.subheadings && section.subheadings.length > 0 && (
                                    <div className="mt-2">
                                      <h5 className="text-neon-blue text-sm font-medium">Subheadings:</h5>
                                      <ul className="text-gray-300 text-sm mt-1 list-disc list-inside">
                                        {section.subheadings.map((subheading: string, i: number) => (
                                          <li key={i}>{subheading}</li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}
                                  
                                  {section.keyPoints && section.keyPoints.length > 0 && (
                                    <div className="mt-2">
                                      <h5 className="text-neon-blue text-sm font-medium">Key Points:</h5>
                                      <ul className="text-gray-300 text-sm mt-1 list-disc list-inside">
                                        {section.keyPoints.map((point: string, i: number) => (
                                          <li key={i}>{point}</li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}
                                  
                                  {section.wordCount && (
                                    <div className="mt-2 text-gray-400 text-sm">
                                      Word Count: ~{section.wordCount} words
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {briefResult.questionsToAnswer && briefResult.questionsToAnswer.length > 0 && (
                            <div>
                              <h3 className="text-lg font-semibold text-white mb-2">Questions to Answer</h3>
                              <ul className="text-gray-300 list-disc list-inside">
                                {briefResult.questionsToAnswer.map((q: string, i: number) => (
                                  <li key={i} className="mb-1">{q}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          {briefResult.dataNeeded && briefResult.dataNeeded.length > 0 && (
                            <div>
                              <h3 className="text-lg font-semibold text-white mb-2">Data/Statistics Needed</h3>
                              <ul className="text-gray-300 list-disc list-inside">
                                {briefResult.dataNeeded.map((d: string, i: number) => (
                                  <li key={i} className="mb-1">{d}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                        
                        {briefResult.linkingStrategy && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-2">Linking Strategy</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {briefResult.linkingStrategy.internal && briefResult.linkingStrategy.internal.length > 0 && (
                                <div>
                                  <h4 className="text-neon-blue text-sm font-medium">Internal Linking Opportunities:</h4>
                                  <ul className="text-gray-300 list-disc list-inside mt-1">
                                    {briefResult.linkingStrategy.internal.map((link: string, i: number) => (
                                      <li key={i}>{link}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              
                              {briefResult.linkingStrategy.external && briefResult.linkingStrategy.external.length > 0 && (
                                <div>
                                  <h4 className="text-neon-blue text-sm font-medium">External Reference Types:</h4>
                                  <ul className="text-gray-300 list-disc list-inside mt-1">
                                    {briefResult.linkingStrategy.external.map((link: string, i: number) => (
                                      <li key={i}>{link}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {briefResult.cta && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-2">Call-to-Action</h3>
                            <p className="text-gray-300">{briefResult.cta}</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            </TabsContent>
            
            {/* Competitor Analysis Tab */}
            <TabsContent value="competitor-analysis">
              <div className="space-y-6">
                <div className="text-white">
                  <h2 className="text-2xl font-bold mb-3 font-orbitron">Competitor Analysis</h2>
                  <p className="text-gray-400 mb-6">
                    Analyze your competitors' SEO strategies and identify opportunities to gain a competitive edge.
                  </p>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="comp-url">Your Website URL</Label>
                      <Input
                        id="comp-url"
                        placeholder="https://your-website.com"
                        value={compUrl}
                        onChange={(e) => setCompUrl(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="comp-competitors">Competitor URLs (one per line)</Label>
                      <Textarea
                        id="comp-competitors"
                        placeholder="https://competitor1.com
https://competitor2.com
https://competitor3.com"
                        value={compCompetitors}
                        onChange={(e) => setCompCompetitors(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple h-32"
                      />
                    </div>
                    
                    <Button
                      onClick={() => competitorAnalysisMutation.mutate()}
                      disabled={!compUrl || !compCompetitors || isPending}
                      className="w-full bg-gradient-to-r from-neon-purple to-neon-blue text-white py-3 px-4 rounded-md font-medium shadow-lg hover:shadow-xl neon-button transition flex items-center justify-center"
                    >
                      {competitorAnalysisMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Analyzing Competitors...
                        </>
                      ) : (
                        'Analyze Competitors (100 Tokens)'
                      )}
                    </Button>
                  </div>
                </div>
                
                {compResult && (
                  <div className="mt-8">
                    <Card className="bg-cyberpunk-card border-neon-blue">
                      <CardHeader>
                        <CardTitle className="text-white">Competitor Analysis Results</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {compResult.competitorInsights && compResult.competitorInsights.length > 0 && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-4">Competitor Insights</h3>
                            {compResult.competitorInsights.map((competitor: any, index: number) => (
                              <div key={index} className="mb-6">
                                <div className="bg-gradient-to-r from-neon-purple/20 to-neon-blue/20 p-3 rounded-t-lg border-b border-neon-blue">
                                  <h4 className="text-white font-medium">{competitor.domain}</h4>
                                </div>
                                <div className="bg-cyberpunk-card-light p-4 rounded-b-lg border border-t-0 border-gray-700">
                                  <div className="space-y-4">
                                    <div>
                                      <div 
                                        className="flex justify-between items-center cursor-pointer"
                                        onClick={() => toggleSection(`content-${index}`)}
                                      >
                                        <h5 className="text-neon-blue font-medium">Content Strategy</h5>
                                        {expanded[`content-${index}`] ? <ChevronUp className="h-4 w-4 text-gray-400" /> : <ChevronDown className="h-4 w-4 text-gray-400" />}
                                      </div>
                                      {expanded[`content-${index}`] && (
                                        <div className="mt-2 space-y-2">
                                          {competitor.contentStrategy.strengths && competitor.contentStrategy.strengths.length > 0 && (
                                            <div>
                                              <span className="text-neon-green text-sm">Strengths:</span>
                                              <ul className="text-gray-300 text-sm list-disc list-inside ml-2">
                                                {competitor.contentStrategy.strengths.map((s: string, i: number) => (
                                                  <li key={i}>{s}</li>
                                                ))}
                                              </ul>
                                            </div>
                                          )}
                                          {competitor.contentStrategy.weaknesses && competitor.contentStrategy.weaknesses.length > 0 && (
                                            <div>
                                              <span className="text-neon-red text-sm">Weaknesses:</span>
                                              <ul className="text-gray-300 text-sm list-disc list-inside ml-2">
                                                {competitor.contentStrategy.weaknesses.map((w: string, i: number) => (
                                                  <li key={i}>{w}</li>
                                                ))}
                                              </ul>
                                            </div>
                                          )}
                                          {competitor.contentStrategy.keyTakeaways && competitor.contentStrategy.keyTakeaways.length > 0 && (
                                            <div>
                                              <span className="text-neon-blue text-sm">Key Takeaways:</span>
                                              <ul className="text-gray-300 text-sm list-disc list-inside ml-2">
                                                {competitor.contentStrategy.keyTakeaways.map((t: string, i: number) => (
                                                  <li key={i}>{t}</li>
                                                ))}
                                              </ul>
                                            </div>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                    
                                    <Separator className="bg-gray-700" />
                                    
                                    <div>
                                      <div 
                                        className="flex justify-between items-center cursor-pointer"
                                        onClick={() => toggleSection(`keyword-${index}`)}
                                      >
                                        <h5 className="text-neon-blue font-medium">Keyword Strategy</h5>
                                        {expanded[`keyword-${index}`] ? <ChevronUp className="h-4 w-4 text-gray-400" /> : <ChevronDown className="h-4 w-4 text-gray-400" />}
                                      </div>
                                      {expanded[`keyword-${index}`] && (
                                        <div className="mt-2">
                                          {competitor.keywordStrategy.primaryKeywords && competitor.keywordStrategy.primaryKeywords.length > 0 && (
                                            <div>
                                              <span className="text-neon-purple text-sm">Primary Keywords:</span>
                                              <div className="flex flex-wrap gap-2 mt-1">
                                                {competitor.keywordStrategy.primaryKeywords.map((k: string, i: number) => (
                                                  <Badge key={i} className="bg-neon-purple/20 text-neon-purple">{k}</Badge>
                                                ))}
                                              </div>
                                            </div>
                                          )}
                                          {competitor.keywordStrategy.topicClusters && competitor.keywordStrategy.topicClusters.length > 0 && (
                                            <div className="mt-2">
                                              <span className="text-neon-blue text-sm">Topic Clusters:</span>
                                              <ul className="text-gray-300 text-sm list-disc list-inside ml-2">
                                                {competitor.keywordStrategy.topicClusters.map((c: string, i: number) => (
                                                  <li key={i}>{c}</li>
                                                ))}
                                              </ul>
                                            </div>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                    
                                    <Separator className="bg-gray-700" />
                                    
                                    <div>
                                      <div 
                                        className="flex justify-between items-center cursor-pointer"
                                        onClick={() => toggleSection(`technical-${index}`)}
                                      >
                                        <h5 className="text-neon-blue font-medium">Technical SEO</h5>
                                        {expanded[`technical-${index}`] ? <ChevronUp className="h-4 w-4 text-gray-400" /> : <ChevronDown className="h-4 w-4 text-gray-400" />}
                                      </div>
                                      {expanded[`technical-${index}`] && (
                                        <div className="mt-2 space-y-2">
                                          {competitor.technicalSEO.strengths && competitor.technicalSEO.strengths.length > 0 && (
                                            <div>
                                              <span className="text-neon-green text-sm">Strengths:</span>
                                              <ul className="text-gray-300 text-sm list-disc list-inside ml-2">
                                                {competitor.technicalSEO.strengths.map((s: string, i: number) => (
                                                  <li key={i}>{s}</li>
                                                ))}
                                              </ul>
                                            </div>
                                          )}
                                          {competitor.technicalSEO.weaknesses && competitor.technicalSEO.weaknesses.length > 0 && (
                                            <div>
                                              <span className="text-neon-red text-sm">Weaknesses:</span>
                                              <ul className="text-gray-300 text-sm list-disc list-inside ml-2">
                                                {competitor.technicalSEO.weaknesses.map((w: string, i: number) => (
                                                  <li key={i}>{w}</li>
                                                ))}
                                              </ul>
                                            </div>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                        
                        {compResult.opportunityGaps && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-3">Opportunity Gaps</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {compResult.opportunityGaps.content && compResult.opportunityGaps.content.length > 0 && (
                                <div className="bg-cyberpunk-card-light p-4 rounded-lg border border-gray-700">
                                  <h4 className="text-neon-blue font-medium mb-2">Content Gaps</h4>
                                  <ul className="text-gray-300 list-disc list-inside">
                                    {compResult.opportunityGaps.content.map((item: string, i: number) => (
                                      <li key={i}>{item}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              
                              {compResult.opportunityGaps.keywords && compResult.opportunityGaps.keywords.length > 0 && (
                                <div className="bg-cyberpunk-card-light p-4 rounded-lg border border-gray-700">
                                  <h4 className="text-neon-blue font-medium mb-2">Keyword Gaps</h4>
                                  <ul className="text-gray-300 list-disc list-inside">
                                    {compResult.opportunityGaps.keywords.map((item: string, i: number) => (
                                      <li key={i}>{item}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              
                              {compResult.opportunityGaps.technical && compResult.opportunityGaps.technical.length > 0 && (
                                <div className="bg-cyberpunk-card-light p-4 rounded-lg border border-gray-700">
                                  <h4 className="text-neon-blue font-medium mb-2">Technical Gaps</h4>
                                  <ul className="text-gray-300 list-disc list-inside">
                                    {compResult.opportunityGaps.technical.map((item: string, i: number) => (
                                      <li key={i}>{item}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {compResult.actionableRecommendations && compResult.actionableRecommendations.length > 0 && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-3">Actionable Recommendations</h3>
                            <div className="space-y-3">
                              {compResult.actionableRecommendations.map((rec: string, i: number) => (
                                <div key={i} className="flex items-start">
                                  <CheckCircle2 className="h-5 w-5 text-neon-green mr-2 mt-0.5 flex-shrink-0" />
                                  <p className="text-gray-300">{rec}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            </TabsContent>
            
            {/* Keyword Gap Tab */}
            <TabsContent value="keyword-gap">
              <div className="space-y-6">
                <div className="text-white">
                  <h2 className="text-2xl font-bold mb-3 font-orbitron">Keyword Gap Analysis</h2>
                  <p className="text-gray-400 mb-6">
                    Identify keyword opportunities where competitors are ranking but you aren't.
                  </p>
                  
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="keyword-url">Your Website URL</Label>
                      <Input
                        id="keyword-url"
                        placeholder="https://your-website.com"
                        value={keywordUrl}
                        onChange={(e) => setKeywordUrl(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="keyword-competitors">Competitor URLs (one per line)</Label>
                      <Textarea
                        id="keyword-competitors"
                        placeholder="https://competitor1.com
https://competitor2.com
https://competitor3.com"
                        value={keywordCompetitors}
                        onChange={(e) => setKeywordCompetitors(e.target.value)}
                        disabled={isPending}
                        className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple h-32"
                      />
                    </div>
                    
                    <Button
                      onClick={() => keywordGapMutation.mutate()}
                      disabled={!keywordUrl || !keywordCompetitors || isPending}
                      className="w-full bg-gradient-to-r from-neon-purple to-neon-blue text-white py-3 px-4 rounded-md font-medium shadow-lg hover:shadow-xl neon-button transition flex items-center justify-center"
                    >
                      {keywordGapMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Analyzing Keyword Gaps...
                        </>
                      ) : (
                        'Analyze Keyword Gaps (75 Tokens)'
                      )}
                    </Button>
                  </div>
                </div>
                
                {keywordResult && (
                  <div className="mt-8">
                    <Card className="bg-cyberpunk-card border-neon-blue">
                      <CardHeader>
                        <CardTitle className="text-white">Keyword Gap Analysis Results</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        {keywordResult.keywordGaps && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-4">Keyword Opportunities</h3>
                            
                            {keywordResult.keywordGaps.highPriority && keywordResult.keywordGaps.highPriority.length > 0 && (
                              <div className="mb-4">
                                <h4 className="text-neon-red font-medium mb-2">High Priority Keywords</h4>
                                <div className="space-y-3">
                                  {keywordResult.keywordGaps.highPriority.map((kw: any, i: number) => (
                                    <div key={i} className="bg-cyberpunk-card-light p-3 rounded-lg border border-gray-700">
                                      <div className="flex items-start">
                                        <div className="flex-grow">
                                          <div className="flex items-center">
                                            <h5 className="text-white font-medium">{kw.keyword}</h5>
                                            <Badge className="ml-2 bg-neon-red/20 text-neon-red text-xs">high priority</Badge>
                                          </div>
                                          
                                          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2 text-sm">
                                            {kw.searchVolume && (
                                              <div>
                                                <span className="text-neon-blue">Est. Search Volume:</span>
                                                <span className="text-gray-300 ml-1">{kw.searchVolume}</span>
                                              </div>
                                            )}
                                            
                                            {kw.difficulty && (
                                              <div>
                                                <span className="text-neon-blue">Difficulty:</span>
                                                <span className="text-gray-300 ml-1">{kw.difficulty}</span>
                                              </div>
                                            )}
                                            
                                            {kw.competitors && kw.competitors.length > 0 && (
                                              <div>
                                                <span className="text-neon-blue">Used by:</span>
                                                <span className="text-gray-300 ml-1">{kw.competitors.join(', ')}</span>
                                              </div>
                                            )}
                                          </div>
                                          
                                          {kw.contentRecommendation && (
                                            <div className="mt-2 text-gray-400 text-sm">
                                              <span className="text-neon-green font-medium">Recommendation:</span> {kw.contentRecommendation}
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            
                            {keywordResult.keywordGaps.mediumPriority && keywordResult.keywordGaps.mediumPriority.length > 0 && (
                              <div className="mb-4">
                                <h4 className="text-amber-500 font-medium mb-2">Medium Priority Keywords</h4>
                                <div className="space-y-3">
                                  {keywordResult.keywordGaps.mediumPriority.map((kw: any, i: number) => (
                                    <div key={i} className="bg-cyberpunk-card-light p-3 rounded-lg border border-gray-700">
                                      <div className="flex items-start">
                                        <div className="flex-grow">
                                          <div className="flex items-center">
                                            <h5 className="text-white font-medium">{kw.keyword}</h5>
                                            <Badge className="ml-2 bg-amber-500/20 text-amber-500 text-xs">medium priority</Badge>
                                          </div>
                                          
                                          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mt-2 text-sm">
                                            {kw.searchVolume && (
                                              <div>
                                                <span className="text-neon-blue">Est. Search Volume:</span>
                                                <span className="text-gray-300 ml-1">{kw.searchVolume}</span>
                                              </div>
                                            )}
                                            
                                            {kw.difficulty && (
                                              <div>
                                                <span className="text-neon-blue">Difficulty:</span>
                                                <span className="text-gray-300 ml-1">{kw.difficulty}</span>
                                              </div>
                                            )}
                                            
                                            {kw.competitors && kw.competitors.length > 0 && (
                                              <div>
                                                <span className="text-neon-blue">Used by:</span>
                                                <span className="text-gray-300 ml-1">{kw.competitors.join(', ')}</span>
                                              </div>
                                            )}
                                          </div>
                                          
                                          {kw.contentRecommendation && (
                                            <div className="mt-2 text-gray-400 text-sm">
                                              <span className="text-neon-green font-medium">Recommendation:</span> {kw.contentRecommendation}
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                        
                        {keywordResult.topicGaps && keywordResult.topicGaps.length > 0 && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-3">Content Topic Gaps</h3>
                            <div className="space-y-3">
                              {keywordResult.topicGaps.map((topic: any, i: number) => (
                                <div key={i} className="bg-cyberpunk-card-light p-4 rounded-lg border border-gray-700">
                                  <h4 className="text-white font-medium">{topic.topic}</h4>
                                  
                                  {topic.relatedKeywords && topic.relatedKeywords.length > 0 && (
                                    <div className="mt-2">
                                      <h5 className="text-neon-blue text-sm font-medium">Related Keywords:</h5>
                                      <div className="flex flex-wrap gap-2 mt-1">
                                        {topic.relatedKeywords.map((kw: string, idx: number) => (
                                          <Badge key={idx} className="bg-neon-purple/20 text-neon-purple">{kw}</Badge>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                  
                                  {topic.competitorsRanking && topic.competitorsRanking.length > 0 && (
                                    <div className="mt-2 text-gray-400 text-sm">
                                      <span className="text-neon-blue font-medium">Competitors Ranking:</span> {topic.competitorsRanking.join(', ')}
                                    </div>
                                  )}
                                  
                                  {topic.contentRecommendation && (
                                    <div className="mt-2 text-gray-400 text-sm">
                                      <span className="text-neon-green font-medium">Recommendation:</span> {topic.contentRecommendation}
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {keywordResult.actionPlan && (
                          <div>
                            <h3 className="text-lg font-semibold text-white mb-3">Action Plan</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              {keywordResult.actionPlan.immediateActions && keywordResult.actionPlan.immediateActions.length > 0 && (
                                <div className="bg-cyberpunk-card-light p-4 rounded-lg border border-neon-red">
                                  <h4 className="text-neon-red font-medium mb-2">Immediate Actions</h4>
                                  <ul className="text-gray-300 list-disc list-inside">
                                    {keywordResult.actionPlan.immediateActions.map((action: string, idx: number) => (
                                      <li key={idx} className="mb-1">{action}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              
                              {keywordResult.actionPlan.mediumTermActions && keywordResult.actionPlan.mediumTermActions.length > 0 && (
                                <div className="bg-cyberpunk-card-light p-4 rounded-lg border border-amber-500">
                                  <h4 className="text-amber-500 font-medium mb-2">Medium Term Actions</h4>
                                  <ul className="text-gray-300 list-disc list-inside">
                                    {keywordResult.actionPlan.mediumTermActions.map((action: string, idx: number) => (
                                      <li key={idx} className="mb-1">{action}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                              
                              {keywordResult.actionPlan.longTermStrategy && keywordResult.actionPlan.longTermStrategy.length > 0 && (
                                <div className="bg-cyberpunk-card-light p-4 rounded-lg border border-neon-green">
                                  <h4 className="text-neon-green font-medium mb-2">Long Term Strategy</h4>
                                  <ul className="text-gray-300 list-disc list-inside">
                                    {keywordResult.actionPlan.longTermStrategy.map((action: string, idx: number) => (
                                      <li key={idx} className="mb-1">{action}</li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default AdvancedTools;