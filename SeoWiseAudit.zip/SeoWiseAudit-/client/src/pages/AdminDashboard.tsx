import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  UserRound, 
  Users, 
  BarChart, 
  FileText, 
  Activity, 
  Search, 
  Bell, 
  LogOut,
  Loader2 
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Input } from "@/components/ui/input";

const AdminDashboard = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [audits, setAudits] = useState<any[]>([]);
  const [recentRegistrations, setRecentRegistrations] = useState<any[]>([]);
  const [activeUsers, setActiveUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [tokenAmount, setTokenAmount] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredUsers, setFilteredUsers] = useState<any[]>([]);

  useEffect(() => {
    // Check if admin is logged in
    apiRequest("GET", "/api/user/current")
      .then(res => res.json())
      .then(user => {
        if (!user.isAdmin) {
          toast({
            title: "Access Denied",
            description: "You don't have permission to access this page",
            variant: "destructive",
          });
          navigate("/");
        } else {
          loadData();
        }
      })
      .catch(() => {
        toast({
          title: "Authentication Error",
          description: "Please log in to access this page",
          variant: "destructive",
        });
        navigate("/auth");
      });
  }, []);

  useEffect(() => {
    // Filter users based on search query
    if (searchQuery && users.length > 0) {
      setFilteredUsers(
        users.filter(user => 
          user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.email.toLowerCase().includes(searchQuery.toLowerCase())
        )
      );
    } else {
      setFilteredUsers(users);
    }
  }, [searchQuery, users]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load all required data in parallel
      const [statsRes, usersRes, auditsRes, recentRegistrationsRes, activeUsersRes] = await Promise.all([
        apiRequest("GET", "/api/admin/stats"),
        apiRequest("GET", "/api/admin/users"),
        apiRequest("GET", "/api/admin/audits"),
        apiRequest("GET", "/api/admin/recent-registrations"),
        apiRequest("GET", "/api/admin/active-users")
      ]);

      const statsData = await statsRes.json();
      const usersData = await usersRes.json();
      const auditsData = await auditsRes.json();
      const recentRegistrationsData = await recentRegistrationsRes.json();
      const activeUsersData = await activeUsersRes.json();

      setStats(statsData);
      setUsers(usersData);
      setFilteredUsers(usersData);
      setAudits(auditsData);
      setRecentRegistrations(recentRegistrationsData);
      setActiveUsers(activeUsersData);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load admin data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      toast({
        title: "Logged Out",
        description: "Admin session ended successfully",
      });
      navigate("/auth");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to log out",
        variant: "destructive",
      });
    }
  };

  const handleViewUser = async (userId: number) => {
    setLoading(true);
    try {
      const response = await apiRequest("GET", `/api/admin/users/${userId}`);
      const userData = await response.json();
      setSelectedUser(userData);
      setTokenAmount(0); // Reset token amount input
      setActiveTab("user-detail");
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load user details",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateTokens = async () => {
    if (!selectedUser) return;
    
    try {
      const response = await apiRequest("POST", `/api/admin/users/${selectedUser.user.id}/tokens`, {
        tokens: tokenAmount
      });
      
      const updatedUser = await response.json();
      
      setSelectedUser({
        ...selectedUser,
        user: {
          ...selectedUser.user,
          tokens: updatedUser.tokens
        }
      });
      
      toast({
        title: "Tokens Updated",
        description: `User now has ${updatedUser.tokens} tokens`,
      });
      
      // Refresh users list to show updated tokens
      const usersRes = await apiRequest("GET", "/api/admin/users");
      const usersData = await usersRes.json();
      setUsers(usersData);
      setFilteredUsers(usersData);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update tokens",
        variant: "destructive",
      });
    }
  };

  if (loading && !stats && !users.length) {
    return (
      <div className="min-h-screen bg-cyberpunk-bg flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-neon-blue" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cyberpunk-bg">
      <div className="flex h-screen">
        {/* Admin Sidebar */}
        <div className="w-64 bg-cyberpunk-card border-r border-gray-700 flex flex-col">
          <div className="p-4 border-b border-gray-700">
            <h2 className="text-xl font-orbitron text-neon-blue flex items-center">
              <UserRound className="mr-2 h-6 w-6" />
              ADMIN PANEL
            </h2>
          </div>
          
          <nav className="flex-1 p-4">
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => setActiveTab("dashboard")}
                  className={`w-full flex items-center p-2 rounded-md ${
                    activeTab === "dashboard" 
                      ? "bg-neon-blue/20 text-neon-blue" 
                      : "text-gray-300 hover:bg-cyberpunk-card-light"
                  }`}
                >
                  <BarChart className="mr-2 h-5 w-5" />
                  Dashboard
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab("users")}
                  className={`w-full flex items-center p-2 rounded-md ${
                    activeTab === "users" 
                      ? "bg-neon-blue/20 text-neon-blue" 
                      : "text-gray-300 hover:bg-cyberpunk-card-light"
                  }`}
                >
                  <Users className="mr-2 h-5 w-5" />
                  Users
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab("audits")}
                  className={`w-full flex items-center p-2 rounded-md ${
                    activeTab === "audits" 
                      ? "bg-neon-blue/20 text-neon-blue" 
                      : "text-gray-300 hover:bg-cyberpunk-card-light"
                  }`}
                >
                  <FileText className="mr-2 h-5 w-5" />
                  Audits
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab("activity")}
                  className={`w-full flex items-center p-2 rounded-md ${
                    activeTab === "activity" 
                      ? "bg-neon-blue/20 text-neon-blue" 
                      : "text-gray-300 hover:bg-cyberpunk-card-light"
                  }`}
                >
                  <Activity className="mr-2 h-5 w-5" />
                  Activity
                </button>
              </li>
            </ul>
          </nav>
          
          <div className="p-4 border-t border-gray-700">
            <button
              onClick={handleLogout}
              className="w-full flex items-center p-2 text-gray-300 hover:bg-cyberpunk-card-light rounded-md"
            >
              <LogOut className="mr-2 h-5 w-5" />
              Logout
            </button>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="flex-1 overflow-auto">
          <header className="bg-cyberpunk-card border-b border-gray-700 p-4 flex justify-between items-center">
            <h1 className="text-xl font-semibold text-white">
              {activeTab === "dashboard" && "Dashboard"}
              {activeTab === "users" && "User Management"}
              {activeTab === "audits" && "Audit Reports"}
              {activeTab === "activity" && "Recent Activity"}
              {activeTab === "user-detail" && "User Details"}
            </h1>
            
            <div className="flex items-center space-x-4">
              <Button
                variant="outline"
                size="icon"
                className="relative"
                onClick={() => setActiveTab("activity")}
              >
                <Bell className="h-5 w-5" />
                {recentRegistrations.length > 0 && (
                  <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-neon-red flex items-center justify-center text-[10px] text-white">
                    {recentRegistrations.length}
                  </span>
                )}
              </Button>
              
              <div className="h-8 w-8 rounded-full bg-neon-blue/20 flex items-center justify-center">
                <span className="text-neon-blue font-medium">A</span>
              </div>
            </div>
          </header>
          
          <main className="p-6">
            {/* Dashboard Tab */}
            {activeTab === "dashboard" && stats && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <Card className="bg-cyberpunk-card border-gray-700">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-gray-400 text-sm font-medium">Total Users</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-white">{stats.totalUsers}</div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-cyberpunk-card border-gray-700">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-gray-400 text-sm font-medium">Total Audits</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-white">{stats.totalAudits}</div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-cyberpunk-card border-gray-700">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-gray-400 text-sm font-medium">Recent Audits (7d)</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-white">{stats.recentAudits}</div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-cyberpunk-card border-gray-700">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-gray-400 text-sm font-medium">Tokens Used (7d)</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-white">{stats.totalTokensUsed.toLocaleString()}</div>
                    </CardContent>
                  </Card>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-cyberpunk-card border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-gray-200">Recent Registrations</CardTitle>
                      <CardDescription>New users in the last 24 hours</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {recentRegistrations.length === 0 ? (
                        <p className="text-gray-400">No recent registrations</p>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Username</TableHead>
                              <TableHead>Email</TableHead>
                              <TableHead>Registered</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {recentRegistrations.slice(0, 5).map((user) => (
                              <TableRow key={user.id}>
                                <TableCell>{user.username}</TableCell>
                                <TableCell>{user.email}</TableCell>
                                <TableCell>{format(new Date(user.createdAt), 'HH:mm:ss')}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-cyberpunk-card border-gray-700">
                    <CardHeader>
                      <CardTitle className="text-gray-200">Active Users</CardTitle>
                      <CardDescription>Users active in the last 7 days</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {activeUsers.length === 0 ? (
                        <p className="text-gray-400">No active users</p>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Username</TableHead>
                              <TableHead>Email</TableHead>
                              <TableHead>Tokens</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {activeUsers.slice(0, 5).map((user) => (
                              <TableRow key={user.id}>
                                <TableCell>{user.username}</TableCell>
                                <TableCell>{user.email}</TableCell>
                                <TableCell>{user.tokens}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </CardContent>
                  </Card>
                </div>
                
                <Card className="bg-cyberpunk-card border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-200">System Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-gray-400">Current Server Time</p>
                        <p className="text-white">{format(new Date(stats.todayDate), 'yyyy-MM-dd HH:mm:ss')}</p>
                      </div>
                      <div>
                        <Badge className="bg-neon-green">System Operational</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            
            {/* Users Tab */}
            {activeTab === "users" && (
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="relative w-full max-w-md">
                    <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                    <Input
                      type="text"
                      placeholder="Search users by name or email..."
                      className="pl-8 bg-cyberpunk-card border-gray-700"
                      value={searchQuery}
                      onChange={e => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                
                <Card className="bg-cyberpunk-card border-gray-700">
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Username</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Tokens</TableHead>
                          <TableHead>Registered</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredUsers.map((user) => (
                          <TableRow key={user.id}>
                            <TableCell>{user.id}</TableCell>
                            <TableCell>{user.username}</TableCell>
                            <TableCell>{user.email}</TableCell>
                            <TableCell>{user.tokens}</TableCell>
                            <TableCell>{format(new Date(user.createdAt), 'yyyy-MM-dd')}</TableCell>
                            <TableCell>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleViewUser(user.id)}
                              >
                                View
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            )}
            
            {/* Audits Tab */}
            {activeTab === "audits" && (
              <Card className="bg-cyberpunk-card border-gray-700">
                <CardHeader>
                  <CardTitle className="text-gray-200">All Audits</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>User ID</TableHead>
                        <TableHead>URL</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>AI</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Score</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {audits.map((audit) => (
                        <TableRow key={audit.id}>
                          <TableCell>{audit.id}</TableCell>
                          <TableCell>{audit.userId}</TableCell>
                          <TableCell className="max-w-[200px] truncate">{audit.url}</TableCell>
                          <TableCell>{audit.type}</TableCell>
                          <TableCell>{audit.useAI ? "Yes" : "No"}</TableCell>
                          <TableCell>
                            <Badge
                              className={
                                audit.status === "completed"
                                  ? "bg-neon-green/20 text-neon-green"
                                  : audit.status === "running"
                                  ? "bg-amber-500/20 text-amber-500"
                                  : audit.status === "failed"
                                  ? "bg-neon-red/20 text-neon-red"
                                  : "bg-gray-500/20 text-gray-500"
                              }
                            >
                              {audit.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{audit.score ?? "-"}</TableCell>
                          <TableCell>{format(new Date(audit.createdAt), 'yyyy-MM-dd')}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}
            
            {/* Activity Tab */}
            {activeTab === "activity" && (
              <div className="space-y-6">
                <Card className="bg-cyberpunk-card border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-200">Recent Registrations</CardTitle>
                    <CardDescription>New users in the last 24 hours</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {recentRegistrations.length === 0 ? (
                      <p className="text-gray-400">No recent registrations</p>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Username</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Registered</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {recentRegistrations.map((user) => (
                            <TableRow key={user.id}>
                              <TableCell>{user.username}</TableCell>
                              <TableCell>{user.email}</TableCell>
                              <TableCell>{format(new Date(user.createdAt), 'yyyy-MM-dd HH:mm:ss')}</TableCell>
                              <TableCell>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleViewUser(user.id)}
                                >
                                  View
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
                
                <Card className="bg-cyberpunk-card border-gray-700">
                  <CardHeader>
                    <CardTitle className="text-gray-200">Active Users</CardTitle>
                    <CardDescription>Users active in the last 7 days</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {activeUsers.length === 0 ? (
                      <p className="text-gray-400">No active users</p>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Username</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Tokens</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {activeUsers.map((user) => (
                            <TableRow key={user.id}>
                              <TableCell>{user.username}</TableCell>
                              <TableCell>{user.email}</TableCell>
                              <TableCell>{user.tokens}</TableCell>
                              <TableCell>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleViewUser(user.id)}
                                >
                                  View
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
            
            {/* User Detail Tab */}
            {activeTab === "user-detail" && selectedUser && (
              <div className="space-y-6">
                <Button
                  variant="outline"
                  onClick={() => setActiveTab("users")}
                  className="mb-4"
                >
                  Back to Users
                </Button>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="bg-cyberpunk-card border-gray-700 md:col-span-1">
                    <CardHeader>
                      <CardTitle className="text-gray-200">User Profile</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <p className="text-gray-400 text-sm">User ID</p>
                        <p className="text-white">{selectedUser.user.id}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Username</p>
                        <p className="text-white">{selectedUser.user.username}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Email</p>
                        <p className="text-white">{selectedUser.user.email}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Tokens</p>
                        <p className="text-white">{selectedUser.user.tokens}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Registered</p>
                        <p className="text-white">{format(new Date(selectedUser.user.createdAt), 'yyyy-MM-dd HH:mm:ss')}</p>
                      </div>
                      
                      <div className="pt-4">
                        <h3 className="text-gray-300 font-medium mb-2">Manage Tokens</h3>
                        <div className="flex space-x-2">
                          <Input
                            type="number"
                            value={tokenAmount}
                            onChange={(e) => setTokenAmount(parseInt(e.target.value) || 0)}
                            className="bg-cyberpunk-card-light border-gray-700"
                            placeholder="Amount (+ or -)"
                          />
                          <Button onClick={handleUpdateTokens}>Update</Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-cyberpunk-card border-gray-700 md:col-span-2">
                    <CardHeader>
                      <CardTitle className="text-gray-200">User Audits</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {selectedUser.audits.length === 0 ? (
                        <p className="text-gray-400">No audits found for this user</p>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>ID</TableHead>
                              <TableHead>URL</TableHead>
                              <TableHead>Type</TableHead>
                              <TableHead>AI</TableHead>
                              <TableHead>Status</TableHead>
                              <TableHead>Score</TableHead>
                              <TableHead>Date</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {selectedUser.audits.map((audit: any) => (
                              <TableRow key={audit.id}>
                                <TableCell>{audit.id}</TableCell>
                                <TableCell className="max-w-[200px] truncate">{audit.url}</TableCell>
                                <TableCell>{audit.type}</TableCell>
                                <TableCell>{audit.useAI ? "Yes" : "No"}</TableCell>
                                <TableCell>
                                  <Badge
                                    className={
                                      audit.status === "completed"
                                        ? "bg-neon-green/20 text-neon-green"
                                        : audit.status === "running"
                                        ? "bg-amber-500/20 text-amber-500"
                                        : audit.status === "failed"
                                        ? "bg-neon-red/20 text-neon-red"
                                        : "bg-gray-500/20 text-gray-500"
                                    }
                                  >
                                    {audit.status}
                                  </Badge>
                                </TableCell>
                                <TableCell>{audit.score ?? "-"}</TableCell>
                                <TableCell>{format(new Date(audit.createdAt), 'yyyy-MM-dd')}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;