import NavBar from "@/components/NavBar";
import HeroSection from "@/components/HeroSection";
import TokenCounter from "@/components/TokenCounter";
import AuditTool from "@/components/AuditTool";
import FeaturesShowcase from "@/components/FeaturesShowcase";
import ExampleReport from "@/components/ExampleReport";
import Pricing from "@/components/Pricing";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";

const Home = () => {
  return (
    <div className="min-h-screen">
      <NavBar />
      <HeroSection />
      <TokenCounter />
      <AuditTool />
      <FeaturesShowcase />
      <ExampleReport />
      <Pricing />
      <FAQ />
      <Footer />
    </div>
  );
};

export default Home;
