import { useEffect, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { SeoAuditReport, SeoAudit } from "@/types";
import { jsPDF } from "jspdf";
import { useToast } from "@/hooks/use-toast";

const ReportPage = () => {
  const [, params] = useRoute("/report/:id");
  const reportId = params?.id;
  const { toast } = useToast();
  
  const { data: audit, isLoading: isLoadingAudit } = useQuery<SeoAudit>({
    queryKey: [`/api/audit/${reportId}`],
    enabled: !!reportId,
    staleTime: 300000, // 5 minutes
  });
  
  const { data: report, isLoading: isLoadingReport } = useQuery<SeoAuditReport>({
    queryKey: [`/api/report/${reportId}`],
    enabled: !!reportId,
    staleTime: 300000, // 5 minutes
  });
  
  const isLoading = isLoadingAudit || isLoadingReport;
  
  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Generate and download PDF report
  const generatePDF = useCallback(() => {
    if (!audit || !report) return;
    
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      const pageHeight = doc.internal.pageSize.getHeight();
      const margin = 20;
      let yPos = margin;
      
      // Header with Logo and Title
      doc.setFillColor(30, 41, 59); // Dark blue background
      doc.rect(0, 0, pageWidth, 40, 'F');
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(22);
      doc.setFont('helvetica', 'bold');
      doc.text("SEOWISE Audit Report", margin, 25);
      
      // URL and Date
      doc.setTextColor(80, 80, 80);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      yPos = 50;
      doc.text(`URL: ${audit.url}`, margin, yPos);
      yPos += 10;
      doc.text(`Date: ${new Date(audit.createdAt).toLocaleDateString()}`, margin, yPos);
      yPos += 10;
      doc.text(`Report Type: ${audit.type === 'full' ? 'Full Audit' : 'Basic Audit'}`, margin, yPos);
      yPos += 20;
      
      // Overall Score
      doc.setFillColor(41, 55, 75);
      doc.roundedRect(margin, yPos, pageWidth - 2 * margin, 30, 3, 3, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(14);
      doc.text("Overall SEO Score", margin + 10, yPos + 12);
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.text(`${audit.score || 'N/A'}`, margin + 10, yPos + 25);
      yPos += 40;
      
      // Score Breakdown
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text("Score Breakdown", margin, yPos);
      yPos += 10;
      
      // Scores Table
      const scores = [
        { label: "Technical SEO", score: report.technicalSeoScore },
        { label: "Content Quality", score: report.contentQualityScore },
        { label: "Performance", score: report.performanceScore },
        { label: "Mobile Friendliness", score: report.mobileFriendlinessScore }
      ];
      
      if (report.backlinksScore) {
        scores.push({ label: "Backlinks", score: report.backlinksScore });
      }
      
      const tableWidth = pageWidth - 2 * margin;
      const cellPadding = 5;
      const rowHeight = 12;
      
      doc.setDrawColor(220, 220, 220);
      doc.setFillColor(250, 250, 250);
      doc.rect(margin, yPos, tableWidth, rowHeight + cellPadding, 'F');
      
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text("Category", margin + cellPadding, yPos + cellPadding + 4);
      doc.text("Score", margin + tableWidth - 40, yPos + cellPadding + 4);
      yPos += rowHeight + cellPadding;
      
      scores.forEach((item, index) => {
        const isEven = index % 2 === 0;
        if (isEven) {
          doc.setFillColor(240, 240, 240);
          doc.rect(margin, yPos, tableWidth, rowHeight + cellPadding, 'F');
        }
        
        doc.setFont('helvetica', 'normal');
        doc.text(item.label, margin + cellPadding, yPos + cellPadding + 4);
        doc.text(item.score.toString(), margin + tableWidth - 40, yPos + cellPadding + 4);
        yPos += rowHeight + cellPadding;
      });
      yPos += 10;
      
      // Check if we need a new page for strengths and issues
      if (yPos > pageHeight - 100) {
        doc.addPage();
        yPos = margin;
      }
      
      // Key Strengths
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text("Key Strengths", margin, yPos);
      yPos += 10;
      
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      report.strengths.forEach((strength, index) => {
        if (yPos > pageHeight - 20) {
          doc.addPage();
          yPos = margin;
        }
        doc.text(`• ${strength}`, margin, yPos);
        yPos += 10;
      });
      yPos += 10;
      
      // Check if we need a new page for issues
      if (yPos > pageHeight - 100) {
        doc.addPage();
        yPos = margin;
      }
      
      // Critical Issues
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text("Critical Issues", margin, yPos);
      yPos += 10;
      
      doc.setFontSize(12);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(203, 36, 49);
      report.criticalIssues.forEach((issue, index) => {
        if (yPos > pageHeight - 20) {
          doc.addPage();
          yPos = margin;
        }
        doc.text(`• ${issue}`, margin, yPos);
        yPos += 10;
      });
      yPos += 10;
      doc.setTextColor(80, 80, 80);
      
      // Top Recommendations
      doc.addPage();
      yPos = margin;
      
      doc.setFontSize(18);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 41, 59);
      doc.text("Top Recommendations", margin, yPos);
      yPos += 20;
      
      // Display top 5 recommendations
      const topRecs = report.recommendations.slice(0, 5);
      topRecs.forEach((rec, index) => {
        // Check if we need a new page
        if (yPos > pageHeight - 70) {
          doc.addPage();
          yPos = margin;
        }
        
        // Recommendation title with priority
        doc.setFontSize(14);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(30, 41, 59);
        doc.text(`${index + 1}. ${rec.title}`, margin, yPos);
        yPos += 8;
        
        // Priority label
        const priorityColor = 
          rec.priority === 'high' ? '#C92431' : 
          rec.priority === 'medium' ? '#E6A700' : 
          '#27AE60';
        doc.setTextColor(priorityColor);
        doc.setFontSize(10);
        doc.text(`${rec.priority.toUpperCase()} PRIORITY`, margin, yPos);
        yPos += 10;
        
        // Description
        doc.setTextColor(80, 80, 80);
        doc.setFontSize(12);
        doc.setFont('helvetica', 'normal');
        
        // Handle line breaks for long text
        const splitDesc = doc.splitTextToSize(rec.description, pageWidth - 2 * margin - 10);
        splitDesc.forEach(line => {
          if (yPos > pageHeight - 20) {
            doc.addPage();
            yPos = margin;
          }
          doc.text(line, margin + 5, yPos);
          yPos += 7;
        });
        yPos += 10;
      });
      
      // Footer with SEOWISE branding
      const footerText = "Generated by SEOWISE - Premium SEO Analysis Platform";
      doc.setFontSize(10);
      doc.setTextColor(150, 150, 150);
      doc.text(footerText, pageWidth / 2, pageHeight - 10, { align: 'center' });
      
      // Save the PDF
      const filename = `seo-audit-${audit.url.replace(/[^a-zA-Z0-9]/g, '-')}.pdf`;
      doc.save(filename);
      
      toast({
        title: "PDF Generated",
        description: `Your report has been downloaded as ${filename}`,
      });
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast({
        title: "PDF Generation Failed",
        description: "There was an error creating your PDF report. Please try again later.",
        variant: "destructive",
      });
    }
  }, [audit, report, toast]);
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-neon-purple"></div>
      </div>
    );
  }
  
  if (!audit || !report) {
    return (
      <div className="min-h-screen">
        <NavBar />
        <div className="pt-24 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center justify-center">
          <h1 className="text-3xl font-orbitron text-white mb-4">Report Not Found</h1>
          <p className="text-gray-400 mb-6">The SEO audit report you're looking for doesn't exist or you don't have access to it.</p>
          <Link href="/dashboard">
            <Button className="bg-gradient-to-r from-neon-purple to-neon-blue text-white px-6 py-3 rounded-md font-medium neon-button transition">
              Back to Dashboard
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen">
      <NavBar />
      
      <div className="pt-24 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <Link href="/dashboard">
              <a className="text-neon-blue hover:text-neon-purple transition-colors flex items-center mb-2">
                <i className="fas fa-arrow-left mr-2"></i> Back to Dashboard
              </a>
            </Link>
            <h1 className="text-3xl font-bold font-orbitron text-white">{audit.url}</h1>
            <p className="text-gray-400">SEO Audit Report • {new Date(audit.createdAt).toLocaleDateString()}</p>
          </div>
          <div className="mt-4 md:mt-0">
            <Button 
              onClick={generatePDF}
              className="bg-cyberpunk-card-light text-white px-4 py-2 rounded-md font-medium hover:bg-cyberpunk-card hover:text-neon-blue transition flex items-center"
            >
              <i className="fas fa-download mr-2"></i> Download PDF
            </Button>
          </div>
        </div>
        
        <div className="glass-effect rounded-xl p-8 neon-border mb-8">
          <h2 className="text-2xl font-bold font-orbitron text-white mb-6">Executive Summary</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
            <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
              <div className="cyberpunk-progress mb-2">
                <div 
                  className="cyberpunk-progress-bar" 
                  style={{ width: `${report.technicalSeoScore}%` }}
                ></div>
              </div>
              <p className="text-2xl font-bold font-orbitron text-white">{report.technicalSeoScore}</p>
              <p className="text-gray-400 text-sm">Technical SEO</p>
            </div>
            
            <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
              <div className="cyberpunk-progress mb-2">
                <div 
                  className="cyberpunk-progress-bar" 
                  style={{ width: `${report.contentQualityScore}%` }}
                ></div>
              </div>
              <p className="text-2xl font-bold font-orbitron text-white">{report.contentQualityScore}</p>
              <p className="text-gray-400 text-sm">Content Quality</p>
            </div>
            
            <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
              <div className="cyberpunk-progress mb-2">
                <div 
                  className="cyberpunk-progress-bar" 
                  style={{ width: `${report.performanceScore}%` }}
                ></div>
              </div>
              <p className="text-2xl font-bold font-orbitron text-white">{report.performanceScore}</p>
              <p className="text-gray-400 text-sm">Performance</p>
            </div>
            
            <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
              <div className="cyberpunk-progress mb-2">
                <div 
                  className="cyberpunk-progress-bar" 
                  style={{ width: `${report.mobileFriendlinessScore}%` }}
                ></div>
              </div>
              <p className="text-2xl font-bold font-orbitron text-white">{report.mobileFriendlinessScore}</p>
              <p className="text-gray-400 text-sm">Mobile</p>
            </div>
            
            <div className="bg-cyberpunk-card-light rounded-lg p-4 text-center">
              <div className="cyberpunk-progress mb-2">
                <div 
                  className="cyberpunk-progress-bar" 
                  style={{ width: `${report.backlinksScore || 0}%` }}
                ></div>
              </div>
              <p className="text-2xl font-bold font-orbitron text-white">{report.backlinksScore || 'N/A'}</p>
              <p className="text-gray-400 text-sm">Backlinks</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Key Strengths */}
            <div>
              <h3 className="text-xl font-bold font-orbitron text-white mb-3">Key Strengths</h3>
              <ul className="space-y-3">
                {report.strengths.map((strength, index) => (
                  <li key={index} className="flex items-start">
                    <i className="fas fa-check-circle text-neon-green mt-1 mr-2"></i>
                    <span className="text-gray-300">{strength}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            {/* Critical Issues */}
            <div>
              <h3 className="text-xl font-bold font-orbitron text-white mb-3">Critical Issues</h3>
              <ul className="space-y-3">
                {report.criticalIssues.map((issue, index) => (
                  <li key={index} className="flex items-start">
                    <i className="fas fa-exclamation-circle text-neon-red mt-1 mr-2"></i>
                    <span className="text-gray-300">{issue}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold font-orbitron text-white mb-3">Secondary Issues</h3>
            <ul className="space-y-3 mb-8">
              {report.secondaryIssues.map((issue, index) => (
                <li key={index} className="flex items-start">
                  <i className="fas fa-info-circle text-neon-yellow mt-1 mr-2"></i>
                  <span className="text-gray-300">{issue}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Recommendations Section */}
        <div className="glass-effect rounded-xl p-8 neon-border mb-8">
          <h2 className="text-2xl font-bold font-orbitron text-white mb-6">Prioritized Recommendations</h2>
          
          <div className="space-y-6">
            {report.recommendations.map((recommendation, index) => (
              <div 
                key={index} 
                className="bg-cyberpunk-card rounded-xl p-6 border border-cyberpunk-card-light"
              >
                <div className="flex items-center mb-4">
                  <div className="h-8 w-8 rounded-full bg-gradient-to-r from-neon-purple to-neon-blue flex items-center justify-center mr-3">
                    <span className="text-sm font-bold">{index + 1}</span>
                  </div>
                  <h3 className="text-lg font-bold font-orbitron text-white">{recommendation.title}</h3>
                  <span className={`ml-auto px-2 py-1 rounded-full text-xs ${
                    recommendation.priority === 'high' ? 'bg-neon-red text-white' : 
                    recommendation.priority === 'medium' ? 'bg-neon-yellow text-black' : 
                    'bg-neon-green text-black'
                  }`}>
                    {recommendation.priority.toUpperCase()} PRIORITY
                  </span>
                </div>
                
                <p className="text-gray-300 mb-4 ml-11">{recommendation.description}</p>
                
                {recommendation.implementationGuide && (
                  <div className="ml-11 bg-cyberpunk-bg rounded-md p-4 text-gray-300 font-mono text-sm overflow-x-auto">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-neon-blue">Implementation Guide</span>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="bg-transparent border border-neon-blue text-white hover:bg-cyberpunk-card-light h-7 px-2 text-xs"
                      >
                        <i className="fas fa-copy mr-1"></i> Copy
                      </Button>
                    </div>
                    <pre className="whitespace-pre-wrap">{recommendation.implementationGuide}</pre>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        
        <div className="flex justify-between items-center">
          <Link href="/dashboard">
            <Button className="bg-transparent border border-neon-blue text-white hover:bg-cyberpunk-card-light neon-button transition">
              Back to Dashboard
            </Button>
          </Link>
          
          <Link href="/#audit-tool">
            <Button className="bg-gradient-to-r from-neon-purple to-neon-blue text-white shadow-lg hover:shadow-xl neon-button transition">
              Run Another Audit
            </Button>
          </Link>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default ReportPage;
