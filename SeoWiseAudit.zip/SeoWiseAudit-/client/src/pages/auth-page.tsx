import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { User } from "@/types";
import NavBar from "@/components/NavBar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Form validation schemas
const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Please confirm your password")
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"]
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

const AuthPage = () => {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  
  // Check for tab parameter and trial in URL
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const tabParam = urlParams.get('tab');
  const trialParam = urlParams.get('trial');
  const [activeTab, setActiveTab] = useState<"login" | "register">(
    tabParam === 'register' || trialParam === 'true' ? "register" : "login"
  );

  // Check if user is already logged in
  const { data: user } = useQuery<User | null>({
    queryKey: ['/api/user/current'],
    retry: false,
    staleTime: 300000, // 5 minutes
  });

  // Redirect to home if already logged in
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: ""
    }
  });

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (values: LoginFormValues) => {
      const res = await apiRequest("POST", "/api/auth/login", values);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Login successful",
        description: "Welcome back to SEOWISE!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/user/current'] });
      navigate("/");
    },
    onError: (error) => {
      toast({
        title: "Login failed",
        description: error.message || "Please check your credentials and try again",
        variant: "destructive",
      });
    }
  });

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (values: RegisterFormValues) => {
      // Remove confirmPassword as it's not needed in the API
      const { confirmPassword, ...userData } = values;
      const res = await apiRequest("POST", "/api/auth/register", userData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "Welcome to SEOWISE! Your account has been created with 250 free tokens.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/user/current'] });
      navigate("/");
    },
    onError: (error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Please check your information and try again",
        variant: "destructive",
      });
    }
  });

  // Show dev login for development
  const handleDevLogin = async () => {
    try {
      await fetch("/api/auth/dev-login");
      queryClient.invalidateQueries({ queryKey: ['/api/user/current'] });
      toast({
        title: "Development login",
        description: "Logged in as test user",
      });
      navigate("/");
    } catch (error) {
      toast({
        title: "Dev login failed",
        description: "Could not log in with test account",
        variant: "destructive",
      });
    }
  };

  const onLoginSubmit = (values: LoginFormValues) => {
    loginMutation.mutate(values);
  };

  const onRegisterSubmit = (values: RegisterFormValues) => {
    registerMutation.mutate(values);
  };

  return (
    <div className="min-h-screen bg-cyberpunk-bg">
      <NavBar />
      
      <div className="pt-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Hero section */}
          <div className="flex flex-col justify-center">
            <h1 className="text-4xl md:text-5xl font-bold font-orbitron mb-6 text-white">
              Access The Future of <span className="text-neon-purple">SEO</span> <span className="text-neon-blue">Analysis</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Join SEOWISE to unlock powerful AI-driven insights and optimization recommendations for your website.
            </p>
            <div className="bg-cyberpunk-card rounded-lg p-6 border border-neon-purple">
              <div className="flex items-center mb-4">
                <div className="mr-4 bg-neon-purple/20 rounded-full p-2">
                  <i className="fas fa-rocket text-neon-purple text-xl"></i>
                </div>
                <div>
                  <h3 className="text-white font-medium">Start with 250 Free Tokens</h3>
                  <p className="text-gray-400 text-sm">Every new account gets free tokens to try our premium features</p>
                </div>
              </div>
              <div className="flex items-center mb-4">
                <div className="mr-4 bg-neon-blue/20 rounded-full p-2">
                  <i className="fas fa-brain text-neon-blue text-xl"></i>
                </div>
                <div>
                  <h3 className="text-white font-medium">AI-Enhanced Analysis</h3>
                  <p className="text-gray-400 text-sm">Leverage Mistral AI for deeper insights into your SEO strategy</p>
                </div>
              </div>
              <div className="flex items-center">
                <div className="mr-4 bg-neon-green/20 rounded-full p-2">
                  <i className="fas fa-chart-line text-neon-green text-xl"></i>
                </div>
                <div>
                  <h3 className="text-white font-medium">Detailed Reports</h3>
                  <p className="text-gray-400 text-sm">Get comprehensive analytics and actionable recommendations</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Auth forms */}
          <div className="glass-effect rounded-xl p-8 neon-border self-start">
            <Tabs
              defaultValue="login"
              value={activeTab}
              onValueChange={(value) => setActiveTab(value as "login" | "register")}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2 mb-8">
                <TabsTrigger value="login" className="text-lg">Sign In</TabsTrigger>
                <TabsTrigger value="register" className="text-lg">Register</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-6">
                    <FormField
                      control={loginForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Email</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="your@email.com"
                              className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Password</FormLabel>
                          <FormControl>
                            <Input
                              type="password"
                              placeholder="••••••••"
                              className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      disabled={loginMutation.isPending}
                      className="w-full bg-gradient-to-r from-neon-purple to-neon-blue text-white py-3 px-4 rounded-md font-medium shadow-lg hover:shadow-xl neon-button transition flex items-center justify-center"
                    >
                      {loginMutation.isPending ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Signing In...
                        </>
                      ) : (
                        "Sign In"
                      )}
                    </Button>
                  </form>
                </Form>
                
                {process.env.NODE_ENV !== 'production' && (
                  <div className="mt-6">
                    <Button
                      type="button"
                      onClick={handleDevLogin}
                      className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white py-3 px-4 rounded-md font-medium"
                    >
                      Dev Login (Test User)
                    </Button>
                  </div>
                )}
                
                <div className="mt-6 text-center">
                  <p className="text-gray-400">
                    Don't have an account?{" "}
                    <button
                      type="button"
                      onClick={() => setActiveTab("register")}
                      className="text-neon-blue hover:text-neon-purple"
                    >
                      Sign up now
                    </button>
                  </p>
                </div>
              </TabsContent>
              
              <TabsContent value="register">
                {trialParam === 'true' && (
                  <div className="mb-6 bg-gradient-to-r from-neon-purple/20 to-neon-blue/20 p-4 rounded-lg border border-neon-blue">
                    <h3 className="text-neon-blue font-medium mb-1">Get Your Free Trial</h3>
                    <p className="text-gray-300 text-sm">
                      Create your account now to receive 250 free tokens and start analyzing your websites instantly!
                    </p>
                  </div>
                )}
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Username</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Choose a username"
                              className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Email</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="your@email.com"
                              className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Password</FormLabel>
                          <FormControl>
                            <Input
                              type="password"
                              placeholder="••••••••"
                              className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-gray-300">Confirm Password</FormLabel>
                          <FormControl>
                            <Input
                              type="password"
                              placeholder="••••••••"
                              className="bg-cyberpunk-card border-cyberpunk-card-light focus:ring-neon-purple focus:border-neon-purple"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button
                      type="submit"
                      disabled={registerMutation.isPending}
                      className="w-full bg-gradient-to-r from-neon-purple to-neon-blue text-white py-3 px-4 rounded-md font-medium shadow-lg hover:shadow-xl neon-button transition flex items-center justify-center mt-6"
                    >
                      {registerMutation.isPending ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Registering...
                        </>
                      ) : (
                        "Create Account"
                      )}
                    </Button>
                  </form>
                </Form>
                
                <div className="mt-6 text-center">
                  <p className="text-gray-400">
                    Already have an account?{" "}
                    <button
                      type="button"
                      onClick={() => setActiveTab("login")}
                      className="text-neon-blue hover:text-neon-purple"
                    >
                      Sign in
                    </button>
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;