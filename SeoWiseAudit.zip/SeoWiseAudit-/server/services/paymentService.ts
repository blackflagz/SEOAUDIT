import { TokenPackage, Payment } from "@shared/schema";
import { storage } from "../storage";
import axios from "axios";

// Define PayPal credentials
const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID || "";
const PAYPAL_SECRET = process.env.PAYPAL_SECRET || "";
const PAYPAL_API_BASE = process.env.NODE_ENV === "production" 
  ? "https://api.paypal.com" 
  : "https://api.sandbox.paypal.com";

class PaymentService {
  constructor() {
    if (!PAYPAL_CLIENT_ID || !PAYPAL_SECRET) {
      console.warn("Warning: PayPal credentials are not set. Payment functionality will be limited.");
    }
  }
  
  /**
   * Create a payment intent with PayPal
   */
  async createPaymentIntent(userId: number, tokenPackage: TokenPackage): Promise<{ id: string; approvalUrl: string }> {
    try {
      // If PayPal credentials are not set, create a simulated payment
      if (!PAYPAL_CLIENT_ID || !PAYPAL_SECRET) {
        // Create a payment record in the database
        const payment = await storage.createPayment({
          userId,
          packageId: tokenPackage.id,
          amount: tokenPackage.price,
          status: 'pending',
        });
        
        // For demonstration, auto-complete the payment after 5 seconds
        setTimeout(async () => {
          await this.processPayment(
            payment.id.toString(),
            "SIMULATED_PAYER",
            "succeeded"
          );
        }, 5000);
        
        return {
          id: payment.id.toString(),
          approvalUrl: `/api/demo-payment/${payment.id}`
        };
      }
      
      // Get PayPal access token
      const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`).toString('base64');
      const tokenResponse = await axios.post(
        `${PAYPAL_API_BASE}/v1/oauth2/token`,
        'grant_type=client_credentials',
        {
          headers: {
            'Authorization': `Basic ${auth}`,
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );
      
      const accessToken = tokenResponse.data.access_token;
      
      // Create PayPal order
      const orderResponse = await axios.post(
        `${PAYPAL_API_BASE}/v2/checkout/orders`,
        {
          intent: "CAPTURE",
          purchase_units: [
            {
              amount: {
                currency_code: "USD",
                value: (tokenPackage.price / 100).toFixed(2) // Convert cents to dollars
              },
              description: `${tokenPackage.name} - ${tokenPackage.tokens} tokens`
            }
          ],
          application_context: {
            return_url: `${process.env.APP_URL || "http://localhost:5000"}/payment/success`,
            cancel_url: `${process.env.APP_URL || "http://localhost:5000"}/payment/cancel`
          }
        },
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          }
        }
      );
      
      const { id: orderId } = orderResponse.data;
      const approvalUrl = orderResponse.data.links.find((link: any) => link.rel === "approve").href;
      
      // Create a payment record in the database
      await storage.createPayment({
        userId,
        packageId: tokenPackage.id,
        amount: tokenPackage.price,
        paymentIntentId: orderId,
        status: 'pending'
      });
      
      return {
        id: orderId,
        approvalUrl
      };
    } catch (error) {
      console.error("Error creating payment intent:", error);
      throw new Error("Failed to create payment intent");
    }
  }
  
  /**
   * Process a completed payment
   */
  async processPayment(paymentId: string, payerId: string, status: string): Promise<void> {
    try {
      // Find the payment
      const paymentIdNumber = parseInt(paymentId);
      let payment: Payment | undefined;
      
      if (!isNaN(paymentIdNumber)) {
        // Find by internal ID (for simulated payments)
        payment = await storage.getPayment(paymentIdNumber);
      } else {
        // Find by PayPal payment ID
        // In a real implementation, we would need a getPaymentByIntentId method
        // For now, we'll just log this case
        console.log(`Processing external payment: ${paymentId}`);
        return;
      }
      
      if (!payment) {
        throw new Error("Payment not found");
      }
      
      // Update payment status
      await storage.updatePaymentStatus(
        payment.id,
        status === "succeeded" ? "succeeded" : "failed",
        paymentId
      );
      
      // If payment succeeded, add tokens to user
      if (status === "succeeded") {
        // Get the token package
        const tokenPackage = await storage.getTokenPackage(payment.packageId!);
        if (!tokenPackage) {
          throw new Error("Token package not found");
        }
        
        // Add tokens to user
        await storage.updateUserTokens(payment.userId, tokenPackage.tokens);
      }
    } catch (error) {
      console.error("Error processing payment:", error);
      throw new Error("Failed to process payment");
    }
  }
}

export const paymentService = new PaymentService();
