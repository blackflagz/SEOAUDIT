import { SeoAudit, SeoAuditReport, InsertSeoAuditReport } from "@shared/schema";
import { SeoRecommendation } from "../types";
import { storage } from "../storage";
import { mistralService } from "./mistralService";
import { analyzeTechnicalSEO, analyzeContentQuality, analyzePerformance, analyzeMobileFriendliness, analyzeBacklinks } from "../utils/seoHelpers";

class SEOAuditService {
  /**
   * Start the SEO audit process
   */
  async startAudit(audit: SeoAudit, useAI: boolean): Promise<void> {
    try {
      // Update audit status to running
      await storage.updateAuditStatus(audit.id, 'running');
      
      // Run the audit asynchronously
      this.performAudit(audit, useAI)
        .catch(error => {
          console.error("Audit error:", error);
          storage.updateAuditStatus(audit.id, 'failed');
        });
    } catch (error) {
      console.error("Error starting audit:", error);
      await storage.updateAuditStatus(audit.id, 'failed');
    }
  }
  
  /**
   * Perform the actual SEO audit
   */
  private async performAudit(audit: SeoAudit, useAI: boolean): Promise<void> {
    try {
      // Step 1: Analyze technical SEO elements
      const technicalSeoResults = await analyzeTechnicalSEO(audit.url);
      
      // Step 2: Analyze content quality
      const contentQualityResults = await analyzeContentQuality(audit.url);
      
      // Step 3: Analyze website performance
      const performanceResults = await analyzePerformance(audit.url);
      
      // Step 4: Analyze mobile friendliness
      const mobileFriendlinessResults = await analyzeMobileFriendliness(audit.url);
      
      // Step 5: Analyze backlinks if full audit
      let backlinksResults = null;
      if (audit.type === 'full') {
        backlinksResults = await analyzeBacklinks(audit.url);
      }
      
      // Calculate overall scores
      const technicalSeoScore = technicalSeoResults.score;
      const contentQualityScore = contentQualityResults.score;
      const performanceScore = performanceResults.score;
      const mobileFriendlinessScore = mobileFriendlinessResults.score;
      const backlinksScore = backlinksResults ? backlinksResults.score : null;
      
      // Calculate overall score (average of other scores)
      const scores = [technicalSeoScore, contentQualityScore, performanceScore, mobileFriendlinessScore];
      if (backlinksScore !== null) {
        scores.push(backlinksScore);
      }
      const overallScore = Math.round(scores.reduce((sum, score) => sum + score, 0) / scores.length);
      
      // Compile strengths, issues, and recommendations
      const strengths = [
        ...technicalSeoResults.strengths,
        ...contentQualityResults.strengths,
        ...performanceResults.strengths,
        ...mobileFriendlinessResults.strengths
      ];
      
      const criticalIssues = [
        ...technicalSeoResults.criticalIssues,
        ...contentQualityResults.criticalIssues,
        ...performanceResults.criticalIssues,
        ...mobileFriendlinessResults.criticalIssues
      ];
      
      const secondaryIssues = [
        ...technicalSeoResults.secondaryIssues,
        ...contentQualityResults.secondaryIssues,
        ...performanceResults.secondaryIssues,
        ...mobileFriendlinessResults.secondaryIssues
      ];
      
      // Limit the number of items in each category for better UX
      const limitedStrengths = strengths.slice(0, 5);
      const limitedCriticalIssues = criticalIssues.slice(0, 5); 
      const limitedSecondaryIssues = secondaryIssues.slice(0, 5);
      
      // Compile recommendations
      let recommendations: SeoRecommendation[] = [
        ...technicalSeoResults.recommendations,
        ...contentQualityResults.recommendations,
        ...performanceResults.recommendations,
        ...mobileFriendlinessResults.recommendations
      ];
      
      if (backlinksResults) {
        limitedStrengths.push(...backlinksResults.strengths.slice(0, 2));
        limitedCriticalIssues.push(...backlinksResults.criticalIssues.slice(0, 2));
        limitedSecondaryIssues.push(...backlinksResults.secondaryIssues.slice(0, 2));
        recommendations.push(...backlinksResults.recommendations);
      }
      
      // Sort recommendations by priority (high, medium, low)
      recommendations.sort((a, b) => {
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      });
      
      // Limit to top 10 recommendations
      recommendations = recommendations.slice(0, 10);
      
      // If AI analysis was requested, enhance with Mistral
      if (useAI) {
        recommendations = await mistralService.enhanceRecommendations(
          audit.url,
          recommendations,
          {
            technicalSeo: technicalSeoResults,
            contentQuality: contentQualityResults,
            performance: performanceResults,
            mobileFriendliness: mobileFriendlinessResults,
            backlinks: backlinksResults
          }
        );
      }
      
      // Create report
      const reportData: InsertSeoAuditReport = {
        auditId: audit.id,
        technicalSeoScore,
        contentQualityScore,
        performanceScore,
        mobileFriendlinessScore,
        backlinksScore,
        strengths: limitedStrengths,
        criticalIssues: limitedCriticalIssues,
        secondaryIssues: limitedSecondaryIssues,
        recommendations
      };
      
      await storage.createAuditReport(reportData);
      
      // Update audit status and score
      await storage.updateAuditScore(audit.id, overallScore);
      await storage.updateAuditStatus(audit.id, 'completed');
      
    } catch (error) {
      console.error("Error performing audit:", error);
      await storage.updateAuditStatus(audit.id, 'failed');
    }
  }
}

export const seoAuditService = new SEOAuditService();
