import { SeoRecommendation } from "../types";
import axios from "axios";

class MistralService {
  private apiKey: string;
  private baseUrl: string = "https://models.inference.ai.azure.com";
  
  constructor() {
    // Use Mistral API key from environment variables
    this.apiKey = process.env.MISTRAL_API_KEY || "";
    if (!this.apiKey) {
      console.warn("Warning: MISTRAL_API_KEY environment variable is not set for Mistral AI integration.");
    }
  }
  
  /**
   * Enhance SEO recommendations using Mistral AI
   */
  async enhanceRecommendations(
    url: string, 
    recommendations: SeoRecommendation[],
    auditResults: any
  ): Promise<SeoRecommendation[]> {
    if (!this.apiKey) {
      console.warn("Mistral AI integration skipped: No Mistral API key provided");
      return recommendations;
    }
    
    try {
      // Prepare the prompt with audit data
      const prompt = this.createPrompt(url, recommendations, auditResults);
      
      // Call Mistral API via Azure Inference endpoint
      const response = await axios.post(
        `${this.baseUrl}/chat/completions`,
        {
          model: "Mistral-large",
          messages: [
            {
              role: "system",
              content: "You are an expert SEO consultant. Your task is to analyze SEO audit data and enhance the recommendations with specific, actionable advice. Provide detailed implementation guidance where appropriate."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 2048,
          top_p: 0.1
        },
        {
          headers: {
            "Authorization": `Bearer ${this.apiKey}`,
            "Content-Type": "application/json"
          }
        }
      );
      
      // Parse and process the AI response
      const enhancedRecommendations = this.processAIResponse(
        response.data.choices[0].message.content,
        recommendations
      );
      
      return enhancedRecommendations;
    } catch (error) {
      console.error("Error calling Mistral AI:", error);
      // Return original recommendations if AI enhancement fails
      return recommendations;
    }
  }
  
  /**
   * Create a prompt for the Mistral AI model
   */
  private createPrompt(
    url: string, 
    recommendations: SeoRecommendation[],
    auditResults: any
  ): string {
    return `
    I need you to enhance these SEO recommendations for the website: ${url}
    
    Here are the current recommendations:
    ${JSON.stringify(recommendations, null, 2)}
    
    Here is the audit data:
    Technical SEO Score: ${auditResults.technicalSeo.score}
    Content Quality Score: ${auditResults.contentQuality.score}
    Performance Score: ${auditResults.performance.score}
    Mobile Friendliness Score: ${auditResults.mobileFriendliness.score}
    ${auditResults.backlinks ? `Backlinks Score: ${auditResults.backlinks.score}` : ''}
    
    For each recommendation:
    1. Expand on the description with more specific details
    2. Add practical implementation guidance where appropriate (code snippets, step-by-step instructions)
    3. Explain the SEO impact of the recommendation
    4. Include relevant keyword suggestions where appropriate
    
    Also, analyze the content of the website to identify:
    - Primary keywords currently targeted
    - Potential keyword gaps or opportunities
    - Semantic keyword clusters that could improve content relevance
    
    Return the enhanced recommendations in the same JSON format as the input, but with more detailed descriptions and implementation guides that include keyword optimization strategies.
    `;
  }
  
  /**
   * Process the AI response to extract enhanced recommendations
   */
  private processAIResponse(
    aiResponse: string,
    originalRecommendations: SeoRecommendation[]
  ): SeoRecommendation[] {
    try {
      // Try to extract JSON from the response
      const jsonMatch = aiResponse.match(/```json\n([\s\S]*?)\n```/) || 
                        aiResponse.match(/```\n([\s\S]*?)\n```/) ||
                        aiResponse.match(/\[([\s\S]*?)\]/);
      
      if (jsonMatch && jsonMatch[1]) {
        const jsonContent = jsonMatch[1].trim();
        const enhancedRecommendations = JSON.parse(
          jsonContent.startsWith('[') ? jsonContent : `[${jsonContent}]`
        );
        
        // Validate the response structure
        if (Array.isArray(enhancedRecommendations) && 
            enhancedRecommendations.length > 0 && 
            'title' in enhancedRecommendations[0]) {
          return enhancedRecommendations;
        }
      }
      
      // If we couldn't extract valid JSON, try to enhance the original recommendations
      // by extracting parts from the AI response
      return this.fallbackProcessing(aiResponse, originalRecommendations);
    } catch (error) {
      console.error("Error processing AI response:", error);
      return originalRecommendations;
    }
  }
  
  /**
   * Fallback processing for when we can't extract valid JSON from the AI response
   */
  private fallbackProcessing(
    aiResponse: string,
    originalRecommendations: SeoRecommendation[]
  ): SeoRecommendation[] {
    // Split response by recommendation titles to try and match them
    return originalRecommendations.map(rec => {
      const titleRegex = new RegExp(`${rec.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}[\\s\\S]*?(?=\\d+\\.\\s|$)`, 'i');
      const match = aiResponse.match(titleRegex);
      
      if (match) {
        const content = match[0].trim();
        // Extract a potential implementation guide if it exists
        const implementationMatch = content.match(/Implementation Guide:[\s\S]*?(?=Impact:|$)/i) ||
                                  content.match(/Implementation:[\s\S]*?(?=Impact:|$)/i);
        
        return {
          ...rec,
          description: content.split("\n")[1]?.trim() || rec.description,
          implementationGuide: implementationMatch ? implementationMatch[0].replace(/Implementation Guide:|Implementation:/i, '').trim() : rec.implementationGuide
        };
      }
      
      return rec;
    });
  }
  
  /**
   * Analyze content optimization opportunities based on provided keywords
   */
  async analyzeContentOptimization(url: string, keywords: string[]): Promise<any> {
    if (!this.apiKey) {
      console.warn("Mistral AI integration skipped: No Mistral API key provided");
      return {
        message: "AI content optimization skipped: API key not configured",
        recommendations: []
      };
    }
    
    try {
      const prompt = `
      Perform a detailed content optimization analysis for the website ${url} targeting these keywords: ${keywords.join(', ')}.
      
      Please analyze the following:
      1. Keyword density and placement
      2. Semantic relevance and related terms
      3. Content structure and readability
      4. Title and meta description optimization
      5. Heading structure (H1, H2, H3)
      6. Internal linking opportunities
      
      For each area, provide:
      - Current status assessment (what's working, what's not)
      - Specific optimization recommendations
      - Implementation steps
      
      Return your analysis in JSON format with these sections:
      {
        "overview": "Brief summary of content optimization status",
        "keywordAnalysis": {
          "primary": "Analysis of primary keyword usage",
          "secondary": "Analysis of secondary keyword usage",
          "gaps": "Identified keyword gaps"
        },
        "contentStructure": {
          "assessment": "Evaluation of content structure",
          "recommendations": "Structure improvement recommendations"
        },
        "readabilityScore": "Score out of 100",
        "optimizationRecommendations": [
          {
            "title": "Recommendation title",
            "description": "Detailed description",
            "implementation": "Implementation steps",
            "priority": "high/medium/low"
          }
        ]
      }
      `;
      
      const response = await axios.post(
        `${this.baseUrl}/chat/completions`,
        {
          model: "Mistral-large",
          messages: [
            {
              role: "system",
              content: "You are an expert SEO content strategist specialized in content optimization. Analyze website content and provide detailed, actionable recommendations based on target keywords."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          temperature: 0.2,
          max_tokens: 2048
        },
        {
          headers: {
            "Authorization": `Bearer ${this.apiKey}`,
            "Content-Type": "application/json"
          }
        }
      );
      
      // Extract the JSON from the response
      const responseText = response.data.choices[0].message.content;
      
      // Try to parse JSON from the response
      try {
        // Look for JSON in markdown code blocks or directly
        const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                         responseText.match(/```\n([\s\S]*?)\n```/) ||
                         responseText.match(/({[\s\S]*?})/);
                         
        if (jsonMatch && jsonMatch[1]) {
          return JSON.parse(jsonMatch[1]);
        }
        
        // If we can't extract JSON with regex, try direct parsing
        return JSON.parse(responseText);
      } catch (parseError) {
        console.error("Error parsing AI response:", parseError);
        return {
          message: "Could not parse AI response",
          rawResponse: responseText
        };
      }
    } catch (error) {
      console.error("Error calling Mistral AI for content optimization:", error);
      return {
        message: "Failed to analyze content optimization",
        error: error.message
      };
    }
  }
  
  /**
   * Generate an AI content brief based on a topic and keywords
   */
  async generateContentBrief(topic: string, keywords: string[], competitors: string[] = []): Promise<any> {
    if (!this.apiKey) {
      console.warn("Mistral AI integration skipped: No Mistral API key provided");
      return {
        message: "AI content brief generation skipped: API key not configured",
        brief: {}
      };
    }
    
    try {
      let competitorsSection = "";
      if (competitors.length > 0) {
        competitorsSection = `
        Consider these competitor URLs for your analysis:
        ${competitors.join('\n')}
        
        For each competitor, identify:
        - Content structure
        - Key topics covered
        - Content gaps compared to their coverage
        `;
      }
      
      const prompt = `
      Create a comprehensive content brief for a new article on "${topic}" targeting these keywords: ${keywords.join(', ')}.
      
      ${competitorsSection}
      
      Your content brief should include:
      
      1. Proposed H1 title (optimized for both SEO and engagement)
      2. Meta description (under 160 characters)
      3. Target word count and content structure
      4. Key sections to include (with H2 headings)
      5. Subsections for each main section (with H3 headings)
      6. Key points to cover in each section
      7. Questions to answer within the content
      8. Types of data/statistics to include
      9. Internal linking opportunities
      10. External reference suggestions
      11. Call-to-action recommendations
      12. SEO considerations:
         - Primary keyword placement
         - Secondary keyword recommendations
         - Semantic keyword clusters
         - Featured snippet opportunities
      
      Return your content brief in this JSON format:
      {
        "title": "Proposed H1 title",
        "metaDescription": "Meta description text",
        "targetWordCount": number,
        "keywordStrategy": {
          "primary": "Primary keyword",
          "secondary": ["Secondary keyword 1", "Secondary keyword 2"],
          "semantic": ["Related term 1", "Related term 2"]
        },
        "contentStructure": [
          {
            "heading": "H2 heading",
            "subheadings": ["H3 subheading 1", "H3 subheading 2"],
            "keyPoints": ["Point 1", "Point 2"],
            "wordCount": number
          }
        ],
        "questionsToAnswer": ["Question 1", "Question 2"],
        "dataNeeded": ["Statistic type 1", "Statistic type 2"],
        "linkingStrategy": {
          "internal": ["Topic idea 1", "Topic idea 2"],
          "external": ["Resource type 1", "Resource type 2"]
        },
        "cta": "Call-to-action recommendation"
      }
      `;
      
      const response = await axios.post(
        `${this.baseUrl}/chat/completions`,
        {
          model: "Mistral-large",
          messages: [
            {
              role: "system",
              content: "You are an expert SEO content strategist specialized in creating comprehensive content briefs. Create detailed, SEO-optimized content plans based on the topic and keywords provided."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          temperature: 0.2,
          max_tokens: 3000
        },
        {
          headers: {
            "Authorization": `Bearer ${this.apiKey}`,
            "Content-Type": "application/json"
          }
        }
      );
      
      // Extract the JSON from the response
      const responseText = response.data.choices[0].message.content;
      
      // Try to parse JSON from the response
      try {
        // Look for JSON in markdown code blocks or directly
        const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                         responseText.match(/```\n([\s\S]*?)\n```/) ||
                         responseText.match(/({[\s\S]*?})/);
                         
        if (jsonMatch && jsonMatch[1]) {
          return JSON.parse(jsonMatch[1]);
        }
        
        // If we can't extract JSON with regex, try direct parsing
        return JSON.parse(responseText);
      } catch (parseError) {
        console.error("Error parsing AI response for content brief:", parseError);
        return {
          message: "Could not parse AI response",
          rawResponse: responseText
        };
      }
    } catch (error) {
      console.error("Error calling Mistral AI for content brief:", error);
      return {
        message: "Failed to generate content brief",
        error: error.message
      };
    }
  }
  
  /**
   * Analyze competitors based on provided URLs
   */
  async analyzeCompetitors(url: string, competitors: string[]): Promise<any> {
    if (!this.apiKey) {
      console.warn("Mistral AI integration skipped: No Mistral API key provided");
      return {
        message: "Competitor analysis skipped: API key not configured",
        analysis: {}
      };
    }
    
    try {
      const prompt = `
      Perform a comprehensive competitor analysis for website ${url} against these competitors:
      ${competitors.join('\n')}
      
      For each competitor, analyze:
      
      1. Content Strategy:
         - Content types and formats used
         - Content depth and expertise level
         - Publishing frequency
         - Target audience focus
      
      2. Keyword Strategy:
         - Primary keywords targeted
         - Content topic clusters
         - Semantic keyword usage
      
      3. Technical SEO:
         - Site structure and information architecture
         - Page speed (if observable)
         - Mobile optimization
         - Schema markup usage
      
      4. On-Page SEO:
         - Title tag and meta description patterns
         - Heading structure
         - URL structure patterns
         - Image optimization
      
      5. Link Building Strategy:
         - Types of backlinks they're earning
         - Content that attracts links
      
      6. Unique Selling Propositions:
         - What differentiates them
         - Value propositions
      
      7. Competitive Advantages and Disadvantages:
         - Where they excel compared to ${url}
         - Where ${url} has advantages
      
      8. Gaps and Opportunities:
         - Content gaps that ${url} could fill
         - Strategic opportunities based on competitor weaknesses
      
      Return your analysis in this JSON format:
      {
        "competitorInsights": [
          {
            "domain": "competitor1.com",
            "contentStrategy": {
              "strengths": [],
              "weaknesses": [],
              "keyTakeaways": []
            },
            "keywordStrategy": {
              "primaryKeywords": [],
              "topicClusters": [],
              "keyTakeaways": []
            },
            "technicalSEO": {
              "strengths": [],
              "weaknesses": [],
              "keyTakeaways": []
            },
            "onPageSEO": {
              "strengths": [],
              "weaknesses": [],
              "keyTakeaways": []
            },
            "linkBuildingStrategy": {
              "strengths": [],
              "weaknesses": [],
              "keyTakeaways": []
            },
            "uniqueSellingPoints": []
          }
        ],
        "competitiveMatrix": {
          "contentScore": {
            "competitor1.com": number,
            "competitor2.com": number
          },
          "technicalScore": {
            "competitor1.com": number,
            "competitor2.com": number
          },
          "authorityScore": {
            "competitor1.com": number,
            "competitor2.com": number
          }
        },
        "opportunityGaps": {
          "content": [],
          "keywords": [],
          "technical": [],
          "other": []
        },
        "actionableRecommendations": []
      }
      `;
      
      const response = await axios.post(
        `${this.baseUrl}/chat/completions`,
        {
          model: "Mistral-large",
          messages: [
            {
              role: "system",
              content: "You are an expert SEO competitive analyst. Analyze websites and provide detailed competitive analysis with actionable insights."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          temperature: 0.2,
          max_tokens: 4000
        },
        {
          headers: {
            "Authorization": `Bearer ${this.apiKey}`,
            "Content-Type": "application/json"
          }
        }
      );
      
      // Extract the JSON from the response
      const responseText = response.data.choices[0].message.content;
      
      // Try to parse JSON from the response
      try {
        // Look for JSON in markdown code blocks or directly
        const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                         responseText.match(/```\n([\s\S]*?)\n```/) ||
                         responseText.match(/({[\s\S]*?})/);
                         
        if (jsonMatch && jsonMatch[1]) {
          return JSON.parse(jsonMatch[1]);
        }
        
        // If we can't extract JSON with regex, try direct parsing
        return JSON.parse(responseText);
      } catch (parseError) {
        console.error("Error parsing AI response for competitor analysis:", parseError);
        return {
          message: "Could not parse AI response",
          rawResponse: responseText
        };
      }
    } catch (error) {
      console.error("Error calling Mistral AI for competitor analysis:", error);
      return {
        message: "Failed to analyze competitors",
        error: error.message
      };
    }
  }
  
  /**
   * Analyze keyword gaps between a website and its competitors
   */
  async analyzeKeywordGap(url: string, competitors: string[]): Promise<any> {
    if (!this.apiKey) {
      console.warn("Mistral AI integration skipped: No Mistral API key provided");
      return {
        message: "Keyword gap analysis skipped: API key not configured",
        analysis: {}
      };
    }
    
    try {
      const prompt = `
      Perform a keyword gap analysis for website ${url} against these competitors:
      ${competitors.join('\n')}
      
      For the keyword gap analysis:
      
      1. Identify primary keywords each competitor appears to be targeting
      2. Determine keyword opportunities where competitors are ranking but ${url} is not
      3. Find semantic keyword clusters each competitor is focusing on
      4. Identify high-value keywords with potentially lower competition
      5. Analyze search intent alignment for key terms
      6. Find content topics that competitors rank for but ${url} doesn't cover
      
      Return your analysis in this JSON format:
      {
        "competitorKeywords": {
          "competitor1.com": {
            "primaryKeywords": ["keyword 1", "keyword 2"],
            "topicClusters": {
              "cluster1": ["term 1", "term 2"],
              "cluster2": ["term 3", "term 4"]
            }
          }
        },
        "keywordGaps": {
          "highPriority": [
            {
              "keyword": "example keyword",
              "searchVolume": "estimated monthly searches",
              "difficulty": "low/medium/high",
              "competitors": ["competitor1.com", "competitor2.com"],
              "contentRecommendation": "Brief recommendation"
            }
          ],
          "mediumPriority": [],
          "lowPriority": []
        },
        "topicGaps": [
          {
            "topic": "Topic name",
            "relatedKeywords": ["keyword 1", "keyword 2"],
            "competitorsRanking": ["competitor1.com"],
            "contentRecommendation": "Brief recommendation"
          }
        ],
        "semanticGaps": {
          "cluster1": ["term 1", "term 2"],
          "cluster2": ["term 3", "term 4"]
        },
        "actionPlan": {
          "immediateActions": [],
          "mediumTermActions": [],
          "longTermStrategy": []
        }
      }
      `;
      
      const response = await axios.post(
        `${this.baseUrl}/chat/completions`,
        {
          model: "Mistral-large",
          messages: [
            {
              role: "system",
              content: "You are an expert SEO keyword researcher. Analyze websites and identify keyword gaps and opportunities between a target site and its competitors."
            },
            {
              role: "user",
              content: prompt
            }
          ],
          temperature: 0.2,
          max_tokens: 4000
        },
        {
          headers: {
            "Authorization": `Bearer ${this.apiKey}`,
            "Content-Type": "application/json"
          }
        }
      );
      
      // Extract the JSON from the response
      const responseText = response.data.choices[0].message.content;
      
      // Try to parse JSON from the response
      try {
        // Look for JSON in markdown code blocks or directly
        const jsonMatch = responseText.match(/```json\n([\s\S]*?)\n```/) || 
                         responseText.match(/```\n([\s\S]*?)\n```/) ||
                         responseText.match(/({[\s\S]*?})/);
                         
        if (jsonMatch && jsonMatch[1]) {
          return JSON.parse(jsonMatch[1]);
        }
        
        // If we can't extract JSON with regex, try direct parsing
        return JSON.parse(responseText);
      } catch (parseError) {
        console.error("Error parsing AI response for keyword gap analysis:", parseError);
        return {
          message: "Could not parse AI response",
          rawResponse: responseText
        };
      }
    } catch (error) {
      console.error("Error calling Mistral AI for keyword gap analysis:", error);
      return {
        message: "Failed to analyze keyword gaps",
        error: error.message
      };
    }
  }
}

export const mistralService = new MistralService();