export interface SeoRecommendation {
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  implementationGuide?: string;
}