import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import bcrypt from "bcryptjs";
import session from "express-session";
import MemoryStore from "memorystore";

// Extend Express Session
declare module 'express-session' {
  interface SessionData {
    userId: number;
    isAdmin?: boolean;
  }
}
import { 
  insertUserSchema, 
  insertSeoAuditSchema,
  AuditType 
} from "@shared/schema";
import { seoAuditService } from "./services/seoAudit";
import { paymentService } from "./services/paymentService";
import { mistralService } from "./services/mistralService";
import { authenticateUser, requireAdmin } from "./middleware/auth";

const TOKENS_COST = {
  basic: 100,
  full: 250,
  ai: 150,
  contentOptimization: 50,
  aiContentBrief: 75,
  competitorAnalysis: 100,
  keywordGap: 75
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const MemoryStoreSession = MemoryStore(session);

  // Configure session
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "seowise-super-secret",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production", maxAge: 86400000 }, // 24 hours
      store: new MemoryStoreSession({
        checkPeriod: 86400000 // prune expired entries every 24h
      })
    })
  );

  // Auth routes

  // Development mock login endpoint
  if (process.env.NODE_ENV !== 'production') {
    app.get("/api/auth/dev-login", async (req, res) => {
      try {
        // Check if we have a test user
        let user = await storage.getUserByEmail("test@example.com");
        
        // If not, create one
        if (!user) {
          const salt = await bcrypt.genSalt(10);
          const hashedPassword = await bcrypt.hash("password123", salt);
          
          user = await storage.createUser({
            username: "TestUser",
            email: "test@example.com",
            password: hashedPassword,
            tokens: 1000 // More test tokens
          });
        }
        
        // Set user session
        req.session.userId = user.id;
        
        return res.status(200).json({
          id: user.id,
          username: user.username,
          email: user.email,
          tokens: user.tokens,
          message: "Logged in for development"
        });
      } catch (error) {
        console.error("Dev login error:", error);
        return res.status(500).json({ message: "Server error" });
      }
    });
  }

  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if user exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(validatedData.password, salt);
      
      // Create user with 250 free tokens
      const user = await storage.createUser({
        ...validatedData,
        password: hashedPassword,
        tokens: 250 // Free trial tokens
      });
      
      // Save user to session
      req.session.userId = user.id;
      
      return res.status(201).json({
        id: user.id,
        username: user.username,
        email: user.email,
        tokens: user.tokens
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      
      // Check for admin login (hidden)
      if (email === "SUPER" && password === "159753") {
        // Set admin session
        req.session.userId = 0; // Special admin ID
        req.session.isAdmin = true;
        
        return res.status(200).json({
          id: 0,
          username: "Admin",
          email: "admin@seowise.com",
          tokens: 999999, // Unlimited tokens
          isAdmin: true
        });
      }
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(400).json({ message: "Invalid credentials" });
      }
      
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(400).json({ message: "Invalid credentials" });
      }
      
      // Save user to session
      req.session.userId = user.id;
      
      return res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email,
        tokens: user.tokens
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Logout
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/user/current", authenticateUser, async (req, res) => {
    try {
      // For admin user
      if (req.isAdmin) {
        return res.status(200).json({
          id: 0,
          username: "Admin",
          email: "admin@seowise.com",
          tokens: 999999,
          isAdmin: true
        });
      }
      
      // For regular user
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email,
        tokens: user.tokens,
        isAdmin: false
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Activate free trial
  app.post("/api/users/free-trial", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // If user already has tokens, they've already activated the trial
      if (user.tokens > 0) {
        return res.status(400).json({ message: "Free trial already activated" });
      }
      
      const updatedUser = await storage.updateUserTokens(user.id, 250);
      
      return res.status(200).json({
        id: updatedUser!.id,
        username: updatedUser!.username,
        email: updatedUser!.email,
        tokens: updatedUser!.tokens
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // SEO Audit routes

  // Create audit
  app.post("/api/audit", authenticateUser, async (req, res) => {
    try {
      const validatedData = insertSeoAuditSchema.parse({
        ...req.body,
        userId: req.userId,
        useAI: req.body.useAI || false
      });
      
      // Calculate token cost
      let tokenCost = validatedData.type === AuditType.BASIC 
        ? TOKENS_COST.basic 
        : TOKENS_COST.full;
      
      if (validatedData.useAI) {
        tokenCost += TOKENS_COST.ai;
      }
      
      // Check if user has enough tokens
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (user.tokens < tokenCost) {
        return res.status(400).json({ 
          message: "Insufficient tokens",
          required: tokenCost,
          available: user.tokens
        });
      }
      
      // Deduct tokens from user
      await storage.updateUserTokens(req.userId, -tokenCost);
      
      // Create audit
      const audit = await storage.createAudit(validatedData);
      
      // Start audit process asynchronously
      seoAuditService.startAudit(audit, validatedData.useAI || false);
      
      return res.status(201).json(audit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Get user audits
  app.get("/api/audits", authenticateUser, async (req, res) => {
    try {
      const audits = await storage.getUserAudits(req.userId);
      return res.status(200).json(audits);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Get audit by ID
  app.get("/api/audit/:id", authenticateUser, async (req, res) => {
    try {
      const auditId = parseInt(req.params.id);
      if (isNaN(auditId)) {
        return res.status(400).json({ message: "Invalid audit ID" });
      }
      
      const audit = await storage.getAudit(auditId);
      if (!audit) {
        return res.status(404).json({ message: "Audit not found" });
      }
      
      // Check if user has permission to access this audit
      if (audit.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      return res.status(200).json(audit);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Get audit report
  app.get("/api/report/:auditId", authenticateUser, async (req, res) => {
    try {
      const auditId = parseInt(req.params.auditId);
      if (isNaN(auditId)) {
        return res.status(400).json({ message: "Invalid audit ID" });
      }
      
      const audit = await storage.getAudit(auditId);
      if (!audit) {
        return res.status(404).json({ message: "Audit not found" });
      }
      
      // Check if user has permission to access this audit
      if (audit.userId !== req.userId) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      // Check if audit is completed
      if (audit.status !== 'completed') {
        return res.status(400).json({ 
          message: "Audit report not ready",
          status: audit.status
        });
      }
      
      const report = await storage.getAuditReport(auditId);
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      return res.status(200).json(report);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Token packages and payment routes

  // Get token packages
  app.get("/api/token-packages", async (req, res) => {
    try {
      const packages = await storage.getTokenPackages();
      return res.status(200).json(packages);
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Create payment intent
  app.post("/api/payment/create-intent", authenticateUser, async (req, res) => {
    try {
      const { packageId } = req.body;
      
      if (!packageId) {
        return res.status(400).json({ message: "Package ID is required" });
      }
      
      const tokenPackage = await storage.getTokenPackage(packageId);
      if (!tokenPackage) {
        return res.status(404).json({ message: "Package not found" });
      }
      
      // Create payment intent with PayPal
      const paymentIntent = await paymentService.createPaymentIntent(
        req.userId,
        tokenPackage
      );
      
      return res.status(200).json({
        paymentId: paymentIntent.id,
        url: paymentIntent.approvalUrl
      });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Process payment webhook
  app.post("/api/payment/webhook", async (req, res) => {
    try {
      const { paymentId, payerId, status } = req.body;
      
      if (!paymentId || !status) {
        return res.status(400).json({ message: "Invalid webhook data" });
      }
      
      // Process payment
      await paymentService.processPayment(paymentId, payerId, status);
      
      return res.status(200).json({ message: "Payment processed" });
    } catch (error) {
      return res.status(500).json({ message: "Server error" });
    }
  });

  // New Features

  // 1. Content Optimization Analysis
  app.post("/api/content-optimization", authenticateUser, async (req, res) => {
    try {
      const { url, keywords } = req.body;
      
      if (!url) {
        return res.status(400).json({ message: "URL is required" });
      }
      
      if (!keywords || !Array.isArray(keywords) || keywords.length === 0) {
        return res.status(400).json({ message: "At least one keyword is required" });
      }
      
      // Check if user has enough tokens
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const tokenCost = TOKENS_COST.contentOptimization;
      if (user.tokens < tokenCost) {
        return res.status(400).json({ 
          message: "Insufficient tokens",
          required: tokenCost,
          available: user.tokens
        });
      }
      
      // Deduct tokens from user
      await storage.updateUserTokens(req.userId, -tokenCost);
      
      // Process content optimization analysis
      const analysisResult = await mistralService.analyzeContentOptimization(url, keywords);
      
      return res.status(200).json(analysisResult);
    } catch (error) {
      console.error("Content optimization error:", error);
      return res.status(500).json({ message: "Failed to analyze content" });
    }
  });

  // 2. AI Content Brief
  app.post("/api/content-brief", authenticateUser, async (req, res) => {
    try {
      const { topic, keywords, competitors } = req.body;
      
      if (!topic) {
        return res.status(400).json({ message: "Topic is required" });
      }
      
      if (!keywords || !Array.isArray(keywords) || keywords.length === 0) {
        return res.status(400).json({ message: "At least one keyword is required" });
      }
      
      // Check if user has enough tokens
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const tokenCost = TOKENS_COST.aiContentBrief;
      if (user.tokens < tokenCost) {
        return res.status(400).json({ 
          message: "Insufficient tokens",
          required: tokenCost,
          available: user.tokens
        });
      }
      
      // Deduct tokens from user
      await storage.updateUserTokens(req.userId, -tokenCost);
      
      // Generate AI content brief
      const brief = await mistralService.generateContentBrief(topic, keywords, competitors || []);
      
      return res.status(200).json(brief);
    } catch (error) {
      console.error("Content brief error:", error);
      return res.status(500).json({ message: "Failed to generate content brief" });
    }
  });

  // 3. Competitor Analysis
  app.post("/api/competitor-analysis", authenticateUser, async (req, res) => {
    try {
      const { url, competitors } = req.body;
      
      if (!url) {
        return res.status(400).json({ message: "URL is required" });
      }
      
      if (!competitors || !Array.isArray(competitors) || competitors.length === 0) {
        return res.status(400).json({ message: "At least one competitor URL is required" });
      }
      
      // Check if user has enough tokens
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const tokenCost = TOKENS_COST.competitorAnalysis;
      if (user.tokens < tokenCost) {
        return res.status(400).json({ 
          message: "Insufficient tokens",
          required: tokenCost,
          available: user.tokens
        });
      }
      
      // Deduct tokens from user
      await storage.updateUserTokens(req.userId, -tokenCost);
      
      // Analyze competitors
      const analysis = await mistralService.analyzeCompetitors(url, competitors);
      
      return res.status(200).json(analysis);
    } catch (error) {
      console.error("Competitor analysis error:", error);
      return res.status(500).json({ message: "Failed to analyze competitors" });
    }
  });

  // 4. Keyword Gap Analysis
  app.post("/api/keyword-gap", authenticateUser, async (req, res) => {
    try {
      const { url, competitors } = req.body;
      
      if (!url) {
        return res.status(400).json({ message: "URL is required" });
      }
      
      if (!competitors || !Array.isArray(competitors) || competitors.length === 0) {
        return res.status(400).json({ message: "At least one competitor URL is required" });
      }
      
      // Check if user has enough tokens
      const user = await storage.getUser(req.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const tokenCost = TOKENS_COST.keywordGap;
      if (user.tokens < tokenCost) {
        return res.status(400).json({ 
          message: "Insufficient tokens",
          required: tokenCost,
          available: user.tokens
        });
      }
      
      // Deduct tokens from user
      await storage.updateUserTokens(req.userId, -tokenCost);
      
      // Analyze keyword gaps
      const analysis = await mistralService.analyzeKeywordGap(url, competitors);
      
      return res.status(200).json(analysis);
    } catch (error) {
      console.error("Keyword gap analysis error:", error);
      return res.status(500).json({ message: "Failed to analyze keyword gaps" });
    }
  });

  // Admin Routes (Hidden at /supermod)
  
  // Get all users
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      return res.status(200).json(users);
    } catch (error) {
      console.error("Admin get users error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Get user by ID for admin
  app.get("/api/admin/users/:id", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get user's audits
      const audits = await storage.getUserAudits(userId);
      
      return res.status(200).json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          tokens: user.tokens,
          createdAt: user.createdAt
        },
        audits
      });
    } catch (error) {
      console.error("Admin get user error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Update user's tokens
  app.post("/api/admin/users/:id/tokens", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { tokens } = req.body;
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      if (typeof tokens !== 'number') {
        return res.status(400).json({ message: "Tokens must be a number" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Update user tokens
      const updatedUser = await storage.updateUserTokens(userId, tokens);
      
      return res.status(200).json({
        id: updatedUser!.id,
        username: updatedUser!.username,
        email: updatedUser!.email,
        tokens: updatedUser!.tokens
      });
    } catch (error) {
      console.error("Admin update tokens error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Get all audits (for admin only)
  app.get("/api/admin/audits", requireAdmin, async (req, res) => {
    try {
      const audits = await storage.getAllAudits();
      return res.status(200).json(audits);
    } catch (error) {
      console.error("Admin get audits error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Get recent registrations
  app.get("/api/admin/recent-registrations", requireAdmin, async (req, res) => {
    try {
      const recentUsers = await storage.getRecentUsers();
      return res.status(200).json(recentUsers);
    } catch (error) {
      console.error("Admin get recent registrations error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Get active users
  app.get("/api/admin/active-users", requireAdmin, async (req, res) => {
    try {
      const activeUsers = await storage.getActiveUsers();
      return res.status(200).json(activeUsers);
    } catch (error) {
      console.error("Admin get active users error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });

  // Get system stats
  app.get("/api/admin/stats", requireAdmin, async (req, res) => {
    try {
      const totalUsers = await storage.getUserCount();
      const totalAudits = await storage.getAuditCount();
      const recentAudits = await storage.getRecentAudits();
      
      // Calculate tokens used
      let totalTokensUsed = 0;
      for (const audit of recentAudits) {
        let tokenCost = audit.type === AuditType.BASIC 
          ? TOKENS_COST.basic 
          : TOKENS_COST.full;
        
        if (audit.useAI) {
          tokenCost += TOKENS_COST.ai;
        }
        
        totalTokensUsed += tokenCost;
      }
      
      return res.status(200).json({
        totalUsers,
        totalAudits,
        recentAudits: recentAudits.length,
        totalTokensUsed,
        todayDate: new Date().toISOString()
      });
    } catch (error) {
      console.error("Admin get stats error:", error);
      return res.status(500).json({ message: "Server error" });
    }
  });

  return httpServer;
}
