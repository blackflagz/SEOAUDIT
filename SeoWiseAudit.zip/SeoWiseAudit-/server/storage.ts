import { 
  User, InsertUser, 
  SeoAudit, InsertSeoAudit,
  SeoAuditReport, InsertSeoAuditReport,
  TokenPackage, InsertTokenPackage,
  Payment, InsertPayment
} from "@shared/schema";

// Interface defining all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserTokens(userId: number, tokens: number): Promise<User | undefined>;
  
  // Admin User operations
  getAllUsers(): Promise<User[]>;
  getRecentUsers(): Promise<User[]>;
  getActiveUsers(): Promise<User[]>;
  getUserCount(): Promise<number>;
  
  // SEO Audit operations
  createAudit(audit: InsertSeoAudit): Promise<SeoAudit>;
  getAudit(id: number): Promise<SeoAudit | undefined>;
  getUserAudits(userId: number): Promise<SeoAudit[]>;
  updateAuditStatus(id: number, status: string): Promise<SeoAudit | undefined>;
  updateAuditScore(id: number, score: number): Promise<SeoAudit | undefined>;
  getAllAudits(): Promise<SeoAudit[]>;
  getRecentAudits(): Promise<SeoAudit[]>;
  getAuditCount(): Promise<number>;
  
  // SEO Audit Report operations
  createAuditReport(report: InsertSeoAuditReport): Promise<SeoAuditReport>;
  getAuditReport(auditId: number): Promise<SeoAuditReport | undefined>;
  
  // Token Package operations
  getTokenPackages(): Promise<TokenPackage[]>;
  getTokenPackage(id: number): Promise<TokenPackage | undefined>;
  
  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPayment(id: number): Promise<Payment | undefined>;
  updatePaymentStatus(id: number, status: string, paymentIntentId?: string): Promise<Payment | undefined>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private seoAudits: Map<number, SeoAudit>;
  private seoAuditReports: Map<number, SeoAuditReport>;
  private tokenPackages: Map<number, TokenPackage>;
  private payments: Map<number, Payment>;
  
  private currentUserId: number;
  private currentAuditId: number;
  private currentReportId: number;
  private currentPaymentId: number;

  constructor() {
    this.users = new Map();
    this.seoAudits = new Map();
    this.seoAuditReports = new Map();
    this.tokenPackages = new Map();
    this.payments = new Map();
    
    this.currentUserId = 1;
    this.currentAuditId = 1;
    this.currentReportId = 1;
    this.currentPaymentId = 1;
    
    // Initialize with demo token packages
    this.initializeTokenPackages();
  }

  // Initialize token packages
  private initializeTokenPackages(): void {
    const packages: InsertTokenPackage[] = [
      {
        name: "Starter Package",
        description: "Perfect for small websites or single page audits",
        price: 349, // $3.49
        tokens: 650,
        isPopular: false,
        isActive: true
      },
      {
        name: "Pro Package",
        description: "Ideal for medium-sized websites with multiple pages",
        price: 999, // $9.99
        tokens: 2000,
        isPopular: true,
        isActive: true
      },
      {
        name: "Enterprise Package",
        description: "Best for large websites or frequent audits",
        price: 1999, // $19.99
        tokens: 5000,
        isPopular: false,
        isActive: true
      }
    ];
    
    packages.forEach((pkg, index) => {
      const id = index + 1;
      this.tokenPackages.set(id, {
        id,
        name: pkg.name,
        description: pkg.description,
        price: pkg.price,
        tokens: pkg.tokens,
        isPopular: pkg.isPopular || false,
        isActive: pkg.isActive || true,
        createdAt: new Date()
      });
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      tokens: insertUser.tokens || 0, // Ensure tokens is not undefined
      createdAt: now,
      updatedAt: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserTokens(userId: number, tokens: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      tokens: user.tokens + tokens,
      updatedAt: new Date()
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // SEO Audit operations
  async createAudit(insertAudit: InsertSeoAudit): Promise<SeoAudit> {
    const id = this.currentAuditId++;
    const now = new Date();
    const audit: SeoAudit = {
      ...insertAudit,
      id,
      useAI: insertAudit.useAI || false, // Ensure useAI is not undefined
      status: 'pending',
      score: null,
      createdAt: now,
      completedAt: null
    };
    this.seoAudits.set(id, audit);
    return audit;
  }

  async getAudit(id: number): Promise<SeoAudit | undefined> {
    return this.seoAudits.get(id);
  }

  async getUserAudits(userId: number): Promise<SeoAudit[]> {
    return Array.from(this.seoAudits.values())
      .filter(audit => audit.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async updateAuditStatus(id: number, status: string): Promise<SeoAudit | undefined> {
    const audit = await this.getAudit(id);
    if (!audit) return undefined;
    
    const updatedAudit: SeoAudit = {
      ...audit,
      status,
      completedAt: status === 'completed' ? new Date() : audit.completedAt
    };
    
    this.seoAudits.set(id, updatedAudit);
    return updatedAudit;
  }

  async updateAuditScore(id: number, score: number): Promise<SeoAudit | undefined> {
    const audit = await this.getAudit(id);
    if (!audit) return undefined;
    
    const updatedAudit: SeoAudit = {
      ...audit,
      score
    };
    
    this.seoAudits.set(id, updatedAudit);
    return updatedAudit;
  }

  // SEO Audit Report operations
  async createAuditReport(insertReport: InsertSeoAuditReport): Promise<SeoAuditReport> {
    const id = this.currentReportId++;
    const report: SeoAuditReport = {
      id,
      auditId: insertReport.auditId,
      technicalSeoScore: insertReport.technicalSeoScore,
      contentQualityScore: insertReport.contentQualityScore,
      performanceScore: insertReport.performanceScore,
      mobileFriendlinessScore: insertReport.mobileFriendlinessScore,
      backlinksScore: insertReport.backlinksScore || null,
      strengths: insertReport.strengths || [],
      criticalIssues: insertReport.criticalIssues || [],
      secondaryIssues: insertReport.secondaryIssues || [],
      recommendations: insertReport.recommendations || [],
      createdAt: new Date()
    };
    this.seoAuditReports.set(id, report);
    return report;
  }

  async getAuditReport(auditId: number): Promise<SeoAuditReport | undefined> {
    return Array.from(this.seoAuditReports.values()).find(
      (report) => report.auditId === auditId
    );
  }

  // Token Package operations
  async getTokenPackages(): Promise<TokenPackage[]> {
    return Array.from(this.tokenPackages.values())
      .filter(pkg => pkg.isActive)
      .sort((a, b) => a.price - b.price);
  }

  async getTokenPackage(id: number): Promise<TokenPackage | undefined> {
    return this.tokenPackages.get(id);
  }

  // Payment operations
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this.currentPaymentId++;
    const now = new Date();
    const payment: Payment = {
      id,
      userId: insertPayment.userId,
      packageId: insertPayment.packageId || null,
      amount: insertPayment.amount,
      status: insertPayment.status || 'pending',
      paymentIntentId: insertPayment.paymentIntentId || null,
      createdAt: now,
      updatedAt: now
    };
    this.payments.set(id, payment);
    return payment;
  }

  async getPayment(id: number): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async updatePaymentStatus(id: number, status: string, paymentIntentId?: string): Promise<Payment | undefined> {
    const payment = await this.getPayment(id);
    if (!payment) return undefined;
    
    const updatedPayment: Payment = {
      ...payment,
      status,
      paymentIntentId: paymentIntentId || payment.paymentIntentId,
      updatedAt: new Date()
    };
    
    this.payments.set(id, updatedPayment);
    return updatedPayment;
  }

  // Admin User Operations
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getRecentUsers(): Promise<User[]> {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000); // 24 hours ago
    
    return Array.from(this.users.values())
      .filter(user => user.createdAt > oneDayAgo)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getActiveUsers(): Promise<User[]> {
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000); // 7 days ago
    
    // Get users who have created audits in the past 7 days
    const activeUserIds = new Set(
      Array.from(this.seoAudits.values())
        .filter(audit => audit.createdAt > sevenDaysAgo)
        .map(audit => audit.userId)
    );
    
    return Array.from(this.users.values())
      .filter(user => activeUserIds.has(user.id))
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getUserCount(): Promise<number> {
    return this.users.size;
  }

  // Admin Audit Operations
  async getAllAudits(): Promise<SeoAudit[]> {
    return Array.from(this.seoAudits.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getRecentAudits(): Promise<SeoAudit[]> {
    const now = new Date();
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000); // 7 days ago
    
    return Array.from(this.seoAudits.values())
      .filter(audit => audit.createdAt > sevenDaysAgo)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getAuditCount(): Promise<number> {
    return this.seoAudits.size;
  }
}

// Export a singleton instance
export const storage = new MemStorage();
