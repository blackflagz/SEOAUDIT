import { Request, Response, NextFunction } from "express";

// Extend express Request type
declare global {
  namespace Express {
    interface Request {
      userId: number;
      isAdmin?: boolean;
    }
  }
}

// Middleware to authenticate users
export const authenticateUser = (req: Request, res: Response, next: NextFunction) => {
  // Check if user is logged in via session
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ message: "Unauthorized - Please log in" });
  }
  
  // Set userId on request for use in route handlers
  req.userId = req.session.userId;
  
  // Set admin flag if applicable
  if (req.session.isAdmin) {
    req.isAdmin = true;
  }
  
  next();
};

// Middleware to check admin access
export const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
  // First authenticate the user
  authenticateUser(req, res, () => {
    // Then check if they're an admin
    if (!req.isAdmin) {
      return res.status(403).json({ message: "Access denied - Admin privileges required" });
    }
    
    next();
  });
};
